/***************************************************************************//**
* \file SERIAL_std.c
* \version 3.20
*
* \brief
*  This file contains the USB Standard request handler.
*
********************************************************************************
* \copyright
* Copyright 2008-2016, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SERIAL_pvt.h"

/***************************************
*   Static data allocation
***************************************/

#if defined(SERIAL_ENABLE_FWSN_STRING)
    static volatile uint8* SERIAL_fwSerialNumberStringDescriptor;
    static volatile uint8  SERIAL_snStringConfirm = SERIAL_FALSE;
#endif  /* (SERIAL_ENABLE_FWSN_STRING) */

#if defined(SERIAL_ENABLE_FWSN_STRING)
    /***************************************************************************
    * Function Name: SERIAL_SerialNumString
    ************************************************************************//**
    *
    *  This function is available only when the User Call Back option in the 
    *  Serial Number String descriptor properties is selected. Application 
    *  firmware can provide the source of the USB device serial number string 
    *  descriptor during run time. The default string is used if the application 
    *  firmware does not use this function or sets the wrong string descriptor.
    *
    *  \param snString:  Pointer to the user-defined string descriptor. The 
    *  string descriptor should meet the Universal Serial Bus Specification 
    *  revision 2.0 chapter 9.6.7
    *  Offset|Size|Value|Description
    *  ------|----|------|---------------------------------
    *  0     |1   |N     |Size of this descriptor in bytes
    *  1     |1   |0x03  |STRING Descriptor Type
    *  2     |N-2 |Number|UNICODE encoded string
    *  
    * *For example:* uint8 snString[16]={0x0E,0x03,'F',0,'W',0,'S',0,'N',0,'0',0,'1',0};
    *
    * \reentrant
    *  No.
    *
    ***************************************************************************/
    void  SERIAL_SerialNumString(uint8 snString[]) 
    {
        SERIAL_snStringConfirm = SERIAL_FALSE;
        
        if (snString != NULL)
        {
            /* Check descriptor validation */
            if ((snString[0u] > 1u) && (snString[1u] == SERIAL_DESCR_STRING))
            {
                SERIAL_fwSerialNumberStringDescriptor = snString;
                SERIAL_snStringConfirm = SERIAL_TRUE;
            }
        }
    }
#endif  /* SERIAL_ENABLE_FWSN_STRING */


/*******************************************************************************
* Function Name: SERIAL_HandleStandardRqst
****************************************************************************//**
*
*  This Routine dispatches standard requests
*
*
* \return
*  TRUE if request handled.
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 SERIAL_HandleStandardRqst(void) 
{
    uint8 requestHandled = SERIAL_FALSE;
    uint8 interfaceNumber;
    uint8 configurationN;
    uint8 bmRequestType = SERIAL_bmRequestTypeReg;

#if defined(SERIAL_ENABLE_STRINGS)
    volatile uint8 *pStr = 0u;
    #if defined(SERIAL_ENABLE_DESCRIPTOR_STRINGS)
        uint8 nStr;
        uint8 descrLength;
    #endif /* (SERIAL_ENABLE_DESCRIPTOR_STRINGS) */
#endif /* (SERIAL_ENABLE_STRINGS) */
    
    static volatile uint8 SERIAL_tBuffer[SERIAL_STATUS_LENGTH_MAX];
    const T_SERIAL_LUT CYCODE *pTmp;

    SERIAL_currentTD.count = 0u;

    if (SERIAL_RQST_DIR_D2H == (bmRequestType & SERIAL_RQST_DIR_MASK))
    {
        /* Control Read */
        switch (SERIAL_bRequestReg)
        {
            case SERIAL_GET_DESCRIPTOR:
                if (SERIAL_DESCR_DEVICE ==SERIAL_wValueHiReg)
                {
                    pTmp = SERIAL_GetDeviceTablePtr();
                    SERIAL_currentTD.pData = (volatile uint8 *)pTmp->p_list;
                    SERIAL_currentTD.count = SERIAL_DEVICE_DESCR_LENGTH;
                    
                    requestHandled  = SERIAL_InitControlRead();
                }
                else if (SERIAL_DESCR_CONFIG == SERIAL_wValueHiReg)
                {
                    pTmp = SERIAL_GetConfigTablePtr((uint8) SERIAL_wValueLoReg);
                    
                    /* Verify that requested descriptor exists */
                    if (pTmp != NULL)
                    {
                        SERIAL_currentTD.pData = (volatile uint8 *)pTmp->p_list;
                        SERIAL_currentTD.count = (uint16)((uint16)(SERIAL_currentTD.pData)[SERIAL_CONFIG_DESCR_TOTAL_LENGTH_HI] << 8u) | \
                                                                            (SERIAL_currentTD.pData)[SERIAL_CONFIG_DESCR_TOTAL_LENGTH_LOW];
                        requestHandled  = SERIAL_InitControlRead();
                    }
                }
                
            #if(SERIAL_BOS_ENABLE)
                else if (SERIAL_DESCR_BOS == SERIAL_wValueHiReg)
                {
                    pTmp = SERIAL_GetBOSPtr();
                    
                    /* Verify that requested descriptor exists */
                    if (pTmp != NULL)
                    {
                        SERIAL_currentTD.pData = (volatile uint8 *)pTmp;
                        SERIAL_currentTD.count = ((uint16)((uint16)(SERIAL_currentTD.pData)[SERIAL_BOS_DESCR_TOTAL_LENGTH_HI] << 8u)) | \
                                                                             (SERIAL_currentTD.pData)[SERIAL_BOS_DESCR_TOTAL_LENGTH_LOW];
                        requestHandled  = SERIAL_InitControlRead();
                    }
                }
            #endif /*(SERIAL_BOS_ENABLE)*/
            
            #if defined(SERIAL_ENABLE_STRINGS)
                else if (SERIAL_DESCR_STRING == SERIAL_wValueHiReg)
                {
                /* Descriptor Strings */
                #if defined(SERIAL_ENABLE_DESCRIPTOR_STRINGS)
                    nStr = 0u;
                    pStr = (volatile uint8 *) &SERIAL_STRING_DESCRIPTORS[0u];
                    
                    while ((SERIAL_wValueLoReg > nStr) && (*pStr != 0u))
                    {
                        /* Read descriptor length from 1st byte */
                        descrLength = *pStr;
                        /* Move to next string descriptor */
                        pStr = &pStr[descrLength];
                        nStr++;
                    }
                #endif /* (SERIAL_ENABLE_DESCRIPTOR_STRINGS) */
                
                /* Microsoft OS String */
                #if defined(SERIAL_ENABLE_MSOS_STRING)
                    if (SERIAL_STRING_MSOS == SERIAL_wValueLoReg)
                    {
                        pStr = (volatile uint8 *)& SERIAL_MSOS_DESCRIPTOR[0u];
                    }
                #endif /* (SERIAL_ENABLE_MSOS_STRING) */
                
                /* SN string */
                #if defined(SERIAL_ENABLE_SN_STRING)
                    if ((SERIAL_wValueLoReg != 0u) && 
                        (SERIAL_wValueLoReg == SERIAL_DEVICE0_DESCR[SERIAL_DEVICE_DESCR_SN_SHIFT]))
                    {
                    #if defined(SERIAL_ENABLE_IDSN_STRING)
                        /* Read DIE ID and generate string descriptor in RAM */
                        SERIAL_ReadDieID(SERIAL_idSerialNumberStringDescriptor);
                        pStr = SERIAL_idSerialNumberStringDescriptor;
                    #elif defined(SERIAL_ENABLE_FWSN_STRING)
                        
                        if(SERIAL_snStringConfirm != SERIAL_FALSE)
                        {
                            pStr = SERIAL_fwSerialNumberStringDescriptor;
                        }
                        else
                        {
                            pStr = (volatile uint8 *)&SERIAL_SN_STRING_DESCRIPTOR[0u];
                        }
                    #else
                        pStr = (volatile uint8 *)&SERIAL_SN_STRING_DESCRIPTOR[0u];
                    #endif  /* (SERIAL_ENABLE_IDSN_STRING) */
                    }
                #endif /* (SERIAL_ENABLE_SN_STRING) */
                
                    if (*pStr != 0u)
                    {
                        SERIAL_currentTD.count = *pStr;
                        SERIAL_currentTD.pData = pStr;
                        requestHandled  = SERIAL_InitControlRead();
                    }
                }
            #endif /*  SERIAL_ENABLE_STRINGS */
                else
                {
                    requestHandled = SERIAL_DispatchClassRqst();
                }
                break;
                
            case SERIAL_GET_STATUS:
                switch (bmRequestType & SERIAL_RQST_RCPT_MASK)
                {
                    case SERIAL_RQST_RCPT_EP:
                        SERIAL_currentTD.count = SERIAL_EP_STATUS_LENGTH;
                        SERIAL_tBuffer[0u]     = SERIAL_EP[SERIAL_wIndexLoReg & SERIAL_DIR_UNUSED].hwEpState;
                        SERIAL_tBuffer[1u]     = 0u;
                        SERIAL_currentTD.pData = &SERIAL_tBuffer[0u];
                        
                        requestHandled  = SERIAL_InitControlRead();
                        break;
                    case SERIAL_RQST_RCPT_DEV:
                        SERIAL_currentTD.count = SERIAL_DEVICE_STATUS_LENGTH;
                        SERIAL_tBuffer[0u]     = SERIAL_deviceStatus;
                        SERIAL_tBuffer[1u]     = 0u;
                        SERIAL_currentTD.pData = &SERIAL_tBuffer[0u];
                        
                        requestHandled  = SERIAL_InitControlRead();
                        break;
                    default:    /* requestHandled is initialized as FALSE by default */
                        break;
                }
                break;
                
            case SERIAL_GET_CONFIGURATION:
                SERIAL_currentTD.count = 1u;
                SERIAL_currentTD.pData = (volatile uint8 *) &SERIAL_configuration;
                requestHandled  = SERIAL_InitControlRead();
                break;
                
            case SERIAL_GET_INTERFACE:
                SERIAL_currentTD.count = 1u;
                SERIAL_currentTD.pData = (volatile uint8 *) &SERIAL_interfaceSetting[SERIAL_wIndexLoReg];
                requestHandled  = SERIAL_InitControlRead();
                break;
                
            default: /* requestHandled is initialized as FALSE by default */
                break;
        }
    }
    else
    {
        /* Control Write */
        switch (SERIAL_bRequestReg)
        {
            case SERIAL_SET_ADDRESS:
                /* Store address to be set in SERIAL_NoDataControlStatusStage(). */
                SERIAL_deviceAddress = (uint8) SERIAL_wValueLoReg;
                requestHandled = SERIAL_InitNoDataControlTransfer();
                break;
                
            case SERIAL_SET_CONFIGURATION:
                configurationN = SERIAL_wValueLoReg;
                
                /* Verify that configuration descriptor exists */
                if(configurationN > 0u)
                {
                    pTmp = SERIAL_GetConfigTablePtr((uint8) configurationN - 1u);
                }
                
                /* Responds with a Request Error when configuration number is invalid */
                if (((configurationN > 0u) && (pTmp != NULL)) || (configurationN == 0u))
                {
                    /* Set new configuration if it has been changed */
                    if(configurationN != SERIAL_configuration)
                    {
                        SERIAL_configuration = (uint8) configurationN;
                        SERIAL_configurationChanged = SERIAL_TRUE;
                        SERIAL_Config(SERIAL_TRUE);
                    }
                    requestHandled = SERIAL_InitNoDataControlTransfer();
                }
                break;
                
            case SERIAL_SET_INTERFACE:
                if (0u != SERIAL_ValidateAlternateSetting())
                {
                    /* Get interface number from the request. */
                    interfaceNumber = SERIAL_wIndexLoReg;
                    SERIAL_interfaceNumber = (uint8) SERIAL_wIndexLoReg;
                     
                    /* Check if alternate settings is changed for interface. */
                    if (SERIAL_interfaceSettingLast[interfaceNumber] != SERIAL_interfaceSetting[interfaceNumber])
                    {
                        SERIAL_configurationChanged = SERIAL_TRUE;
                    
                        /* Change alternate setting for the endpoints. */
                    #if (SERIAL_EP_MANAGEMENT_MANUAL && SERIAL_EP_ALLOC_DYNAMIC)
                        SERIAL_Config(SERIAL_FALSE);
                    #else
                        SERIAL_ConfigAltChanged();
                    #endif /* (SERIAL_EP_MANAGEMENT_MANUAL && SERIAL_EP_ALLOC_DYNAMIC) */
                    }
                    
                    requestHandled = SERIAL_InitNoDataControlTransfer();
                }
                break;
                
            case SERIAL_CLEAR_FEATURE:
                switch (bmRequestType & SERIAL_RQST_RCPT_MASK)
                {
                    case SERIAL_RQST_RCPT_EP:
                        if (SERIAL_wValueLoReg == SERIAL_ENDPOINT_HALT)
                        {
                            requestHandled = SERIAL_ClearEndpointHalt();
                        }
                        break;
                    case SERIAL_RQST_RCPT_DEV:
                        /* Clear device REMOTE_WAKEUP */
                        if (SERIAL_wValueLoReg == SERIAL_DEVICE_REMOTE_WAKEUP)
                        {
                            SERIAL_deviceStatus &= (uint8)~SERIAL_DEVICE_STATUS_REMOTE_WAKEUP;
                            requestHandled = SERIAL_InitNoDataControlTransfer();
                        }
                        break;
                    case SERIAL_RQST_RCPT_IFC:
                        /* Validate interfaceNumber */
                        if (SERIAL_wIndexLoReg < SERIAL_MAX_INTERFACES_NUMBER)
                        {
                            SERIAL_interfaceStatus[SERIAL_wIndexLoReg] &= (uint8) ~SERIAL_wValueLoReg;
                            requestHandled = SERIAL_InitNoDataControlTransfer();
                        }
                        break;
                    default:    /* requestHandled is initialized as FALSE by default */
                        break;
                }
                break;
                
            case SERIAL_SET_FEATURE:
                switch (bmRequestType & SERIAL_RQST_RCPT_MASK)
                {
                    case SERIAL_RQST_RCPT_EP:
                        if (SERIAL_wValueLoReg == SERIAL_ENDPOINT_HALT)
                        {
                            requestHandled = SERIAL_SetEndpointHalt();
                        }
                        break;
                        
                    case SERIAL_RQST_RCPT_DEV:
                        /* Set device REMOTE_WAKEUP */
                        if (SERIAL_wValueLoReg == SERIAL_DEVICE_REMOTE_WAKEUP)
                        {
                            SERIAL_deviceStatus |= SERIAL_DEVICE_STATUS_REMOTE_WAKEUP;
                            requestHandled = SERIAL_InitNoDataControlTransfer();
                        }
                        break;
                        
                    case SERIAL_RQST_RCPT_IFC:
                        /* Validate interfaceNumber */
                        if (SERIAL_wIndexLoReg < SERIAL_MAX_INTERFACES_NUMBER)
                        {
                            SERIAL_interfaceStatus[SERIAL_wIndexLoReg] &= (uint8) ~SERIAL_wValueLoReg;
                            requestHandled = SERIAL_InitNoDataControlTransfer();
                        }
                        break;
                    
                    default:    /* requestHandled is initialized as FALSE by default */
                        break;
                }
                break;
                
            default:    /* requestHandled is initialized as FALSE by default */
                break;
        }
    }
    
    return (requestHandled);
}


#if defined(SERIAL_ENABLE_IDSN_STRING)
    /***************************************************************************
    * Function Name: SERIAL_ReadDieID
    ************************************************************************//**
    *
    *  This routine read Die ID and generate Serial Number string descriptor.
    *
    *  \param descr:  pointer on string descriptor. This string size has to be equal or
    *          greater than SERIAL_IDSN_DESCR_LENGTH.
    *
    *
    * \reentrant
    *  No.
    *
    ***************************************************************************/
    void SERIAL_ReadDieID(uint8 descr[]) 
    {
        const char8 CYCODE hex[] = "0123456789ABCDEF";
        uint8 i;
        uint8 j = 0u;
        uint8 uniqueId[8u];

        if (NULL != descr)
        {
            /* Initialize descriptor header. */
            descr[0u] = SERIAL_IDSN_DESCR_LENGTH;
            descr[1u] = SERIAL_DESCR_STRING;
            
            /* Unique ID size is 8 bytes. */
            CyGetUniqueId((uint32 *) uniqueId);

            /* Fill descriptor with unique device ID. */
            for (i = 2u; i < SERIAL_IDSN_DESCR_LENGTH; i += 4u)
            {
                descr[i]      = (uint8) hex[(uniqueId[j] >> 4u)];
                descr[i + 1u] = 0u;
                descr[i + 2u] = (uint8) hex[(uniqueId[j] & 0x0Fu)];
                descr[i + 3u] = 0u;
                ++j;
            }
        }
    }
#endif /* (SERIAL_ENABLE_IDSN_STRING) */


/*******************************************************************************
* Function Name: SERIAL_ConfigReg
****************************************************************************//**
*
*  This routine configures hardware registers from the variables.
*  It is called from SERIAL_Config() function and from RestoreConfig
*  after Wakeup.
*
*******************************************************************************/
void SERIAL_ConfigReg(void) 
{
    uint8 ep;

#if (SERIAL_EP_MANAGEMENT_DMA_AUTO)
    uint8 epType = 0u;
#endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO) */

    /* Go thought all endpoints and set hardware configuration */
    for (ep = SERIAL_EP1; ep < SERIAL_MAX_EP; ++ep)
    {
        SERIAL_ARB_EP_BASE.arbEp[ep].epCfg = SERIAL_ARB_EPX_CFG_DEFAULT;
        
    #if (SERIAL_EP_MANAGEMENT_DMA)
        /* Enable arbiter endpoint interrupt sources */
        SERIAL_ARB_EP_BASE.arbEp[ep].epIntEn = SERIAL_ARB_EPX_INT_MASK;
    #endif /* (SERIAL_EP_MANAGEMENT_DMA) */
    
        if (SERIAL_EP[ep].epMode != SERIAL_MODE_DISABLE)
        {
            if (0u != (SERIAL_EP[ep].addr & SERIAL_DIR_IN))
            {
                SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = SERIAL_MODE_NAK_IN;
                
            #if (SERIAL_EP_MANAGEMENT_DMA_AUTO && CY_PSOC4)
                /* Clear DMA_TERMIN for IN endpoint. */
                SERIAL_ARB_EP_BASE.arbEp[ep].epIntEn &= (uint32) ~SERIAL_ARB_EPX_INT_DMA_TERMIN;
            #endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO && CY_PSOC4) */
            }
            else
            {
                SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = SERIAL_MODE_NAK_OUT;

            #if (SERIAL_EP_MANAGEMENT_DMA_AUTO)
                /* (CY_PSOC4): DMA_TERMIN for OUT endpoint is set above. */
                
                /* Prepare endpoint type mask. */
                epType |= (uint8) (0x01u << (ep - SERIAL_EP1));
            #endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO) */
            }
        }
        else
        {
            SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = SERIAL_MODE_STALL_DATA_EP;
        }
        
    #if (!SERIAL_EP_MANAGEMENT_DMA_AUTO)
        #if (CY_PSOC4)
            SERIAL_ARB_EP16_BASE.arbEp[ep].rwRa16  = (uint32) SERIAL_EP[ep].buffOffset;
            SERIAL_ARB_EP16_BASE.arbEp[ep].rwWa16  = (uint32) SERIAL_EP[ep].buffOffset;
        #else
            SERIAL_ARB_EP_BASE.arbEp[ep].rwRa    = LO8(SERIAL_EP[ep].buffOffset);
            SERIAL_ARB_EP_BASE.arbEp[ep].rwRaMsb = HI8(SERIAL_EP[ep].buffOffset);
            SERIAL_ARB_EP_BASE.arbEp[ep].rwWa    = LO8(SERIAL_EP[ep].buffOffset);
            SERIAL_ARB_EP_BASE.arbEp[ep].rwWaMsb = HI8(SERIAL_EP[ep].buffOffset);
        #endif /* (CY_PSOC4) */
    #endif /* (!SERIAL_EP_MANAGEMENT_DMA_AUTO) */
    }

#if (SERIAL_EP_MANAGEMENT_DMA_AUTO)
     /* BUF_SIZE depend on DMA_THRESS value:0x55-32 bytes  0x44-16 bytes 0x33-8 bytes 0x22-4 bytes 0x11-2 bytes */
    SERIAL_BUF_SIZE_REG = SERIAL_DMA_BUF_SIZE;

    /* Configure DMA burst threshold */
#if (CY_PSOC4)
    SERIAL_DMA_THRES16_REG   = SERIAL_DMA_BYTES_PER_BURST;
#else
    SERIAL_DMA_THRES_REG     = SERIAL_DMA_BYTES_PER_BURST;
    SERIAL_DMA_THRES_MSB_REG = 0u;
#endif /* (CY_PSOC4) */
    SERIAL_EP_ACTIVE_REG = SERIAL_DEFAULT_ARB_INT_EN;
    SERIAL_EP_TYPE_REG   = epType;
    
    /* Cfg_cmp bit set to 1 once configuration is complete. */
    /* Lock arbiter configtuation */
    SERIAL_ARB_CFG_REG |= (uint8)  SERIAL_ARB_CFG_CFG_CMP;
    /* Cfg_cmp bit set to 0 during configuration of PFSUSB Registers. */
    SERIAL_ARB_CFG_REG &= (uint8) ~SERIAL_ARB_CFG_CFG_CMP;

#endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO) */

    /* Enable interrupt SIE interurpt source from EP0-EP1 */
    SERIAL_SIE_EP_INT_EN_REG = (uint8) SERIAL_DEFAULT_SIE_EP_INT_EN;
}


/*******************************************************************************
* Function Name: SERIAL_EpStateInit
****************************************************************************//**
*
*  This routine initialize state of Data end points based of its type: 
*   IN  - SERIAL_IN_BUFFER_EMPTY (SERIAL_EVENT_PENDING)
*   OUT - SERIAL_OUT_BUFFER_EMPTY (SERIAL_NO_EVENT_PENDING)
*
*******************************************************************************/
void SERIAL_EpStateInit(void) 
{
    uint8 i;

    for (i = SERIAL_EP1; i < SERIAL_MAX_EP; i++)
    { 
        if (0u != (SERIAL_EP[i].addr & SERIAL_DIR_IN))
        {
            /* IN Endpoint */
            SERIAL_EP[i].apiEpState = SERIAL_EVENT_PENDING;
        }
        else
        {
            /* OUT Endpoint */
            SERIAL_EP[i].apiEpState = SERIAL_NO_EVENT_PENDING;
        }
    }
                    
}


/*******************************************************************************
* Function Name: SERIAL_Config
****************************************************************************//**
*
*  This routine configures endpoints for the entire configuration by scanning
*  the configuration descriptor.
*
*  \param clearAltSetting: It configures the bAlternateSetting 0 for each interface.
*
* SERIAL_interfaceClass - Initialized class array for each interface.
*   It is used for handling Class specific requests depend on interface class.
*   Different classes in multiple Alternate settings does not supported.
*
* \reentrant
*  No.
*
*******************************************************************************/
void SERIAL_Config(uint8 clearAltSetting) 
{
    uint8 ep;
    uint8 curEp;
    uint8 i;
    uint8 epType;
    const uint8 *pDescr;
    
    #if (!SERIAL_EP_MANAGEMENT_DMA_AUTO)
        uint16 buffCount = 0u;
    #endif /* (!SERIAL_EP_MANAGEMENT_DMA_AUTO) */

    const T_SERIAL_LUT CYCODE *pTmp;
    const T_SERIAL_EP_SETTINGS_BLOCK CYCODE *pEP;

    /* Clear endpoints settings */
    for (ep = 0u; ep < SERIAL_MAX_EP; ++ep)
    {
        SERIAL_EP[ep].attrib     = 0u;
        SERIAL_EP[ep].hwEpState  = 0u;
        SERIAL_EP[ep].epToggle   = 0u;
        SERIAL_EP[ep].bufferSize = 0u;
        SERIAL_EP[ep].interface  = 0u;
        SERIAL_EP[ep].apiEpState = SERIAL_NO_EVENT_PENDING;
        SERIAL_EP[ep].epMode     = SERIAL_MODE_DISABLE;   
    }

    /* Clear Alternate settings for all interfaces. */
    if (0u != clearAltSetting)
    {
        for (i = 0u; i < SERIAL_MAX_INTERFACES_NUMBER; ++i)
        {
            SERIAL_interfaceSetting[i]     = 0u;
            SERIAL_interfaceSettingLast[i] = 0u;
        }
    }

    /* Init Endpoints and Device Status if configured */
    if (SERIAL_configuration > 0u)
    {
        #if defined(SERIAL_ENABLE_CDC_CLASS)
            uint8 cdcComNums = 0u;
        #endif  /* (SERIAL_ENABLE_CDC_CLASS) */  

        pTmp = SERIAL_GetConfigTablePtr(SERIAL_configuration - 1u);
        
        /* Set Power status for current configuration */
        pDescr = (const uint8 *)pTmp->p_list;
        if ((pDescr[SERIAL_CONFIG_DESCR_ATTRIB] & SERIAL_CONFIG_DESCR_ATTRIB_SELF_POWERED) != 0u)
        {
            SERIAL_deviceStatus |= (uint8)  SERIAL_DEVICE_STATUS_SELF_POWERED;
        }
        else
        {
            SERIAL_deviceStatus &= (uint8) ~SERIAL_DEVICE_STATUS_SELF_POWERED;
        }
        
        /* Move to next element */
        pTmp = &pTmp[1u];
        ep = pTmp->c;  /* For this table, c is the number of endpoints configurations  */

        #if (SERIAL_EP_MANAGEMENT_MANUAL && SERIAL_EP_ALLOC_DYNAMIC)
            /* Configure for dynamic EP memory allocation */
            /* p_list points the endpoint setting table. */
            pEP = (T_SERIAL_EP_SETTINGS_BLOCK *) pTmp->p_list;
            
            for (i = 0u; i < ep; i++)
            {     
                /* Compare current Alternate setting with EP Alt */
                if (SERIAL_interfaceSetting[pEP->interface] == pEP->altSetting)
                {                                                          
                    curEp  = pEP->addr & SERIAL_DIR_UNUSED;
                    epType = pEP->attributes & SERIAL_EP_TYPE_MASK;
                    
                    SERIAL_EP[curEp].addr       = pEP->addr;
                    SERIAL_EP[curEp].attrib     = pEP->attributes;
                    SERIAL_EP[curEp].bufferSize = pEP->bufferSize;

                    if (0u != (pEP->addr & SERIAL_DIR_IN))
                    {
                        /* IN Endpoint */
                        SERIAL_EP[curEp].epMode     = SERIAL_GET_ACTIVE_IN_EP_CR0_MODE(epType);
                        SERIAL_EP[curEp].apiEpState = SERIAL_EVENT_PENDING;
                    
                    #if (defined(SERIAL_ENABLE_MIDI_STREAMING) && (SERIAL_MIDI_IN_BUFF_SIZE > 0))
                        if ((pEP->bMisc == SERIAL_CLASS_AUDIO) && (epType == SERIAL_EP_TYPE_BULK))
                        {
                            SERIAL_midi_in_ep = curEp;
                        }
                    #endif  /* (SERIAL_ENABLE_MIDI_STREAMING) */
                    }
                    else
                    {
                        /* OUT Endpoint */
                        SERIAL_EP[curEp].epMode     = SERIAL_GET_ACTIVE_OUT_EP_CR0_MODE(epType);
                        SERIAL_EP[curEp].apiEpState = SERIAL_NO_EVENT_PENDING;
                        
                    #if (defined(SERIAL_ENABLE_MIDI_STREAMING) && (SERIAL_MIDI_OUT_BUFF_SIZE > 0))
                        if ((pEP->bMisc == SERIAL_CLASS_AUDIO) && (epType == SERIAL_EP_TYPE_BULK))
                        {
                            SERIAL_midi_out_ep = curEp;
                        }
                    #endif  /* (SERIAL_ENABLE_MIDI_STREAMING) */
                    }

                #if(defined (SERIAL_ENABLE_CDC_CLASS))
                    if((pEP->bMisc == SERIAL_CLASS_CDC_DATA) ||(pEP->bMisc == SERIAL_CLASS_CDC))
                    {
                        cdcComNums = SERIAL_Cdc_EpInit(pEP, curEp, cdcComNums);
                    }
                #endif  /* (SERIAL_ENABLE_CDC_CLASS) */
                }
                
                pEP = &pEP[1u];
            }
            
        #else
            for (i = SERIAL_EP1; i < SERIAL_MAX_EP; ++i)
            {
                /* p_list points the endpoint setting table. */
                pEP = (const T_SERIAL_EP_SETTINGS_BLOCK CYCODE *) pTmp->p_list;
                /* Find max length for each EP and select it (length could be different in different Alt settings) */
                /* but other settings should be correct with regards to Interface alt Setting */
                
                for (curEp = 0u; curEp < ep; ++curEp)
                {
                    if (i == (pEP->addr & SERIAL_DIR_UNUSED))
                    {
                        /* Compare endpoint buffers size with current size to find greater. */
                        if (SERIAL_EP[i].bufferSize < pEP->bufferSize)
                        {
                            SERIAL_EP[i].bufferSize = pEP->bufferSize;
                        }
                        
                        /* Compare current Alternate setting with EP Alt */
                        if (SERIAL_interfaceSetting[pEP->interface] == pEP->altSetting)
                        {                            
                            SERIAL_EP[i].addr = pEP->addr;
                            SERIAL_EP[i].attrib = pEP->attributes;
                            
                            epType = pEP->attributes & SERIAL_EP_TYPE_MASK;
                            
                            if (0u != (pEP->addr & SERIAL_DIR_IN))
                            {
                                /* IN Endpoint */
                                SERIAL_EP[i].epMode     = SERIAL_GET_ACTIVE_IN_EP_CR0_MODE(epType);
                                SERIAL_EP[i].apiEpState = SERIAL_EVENT_PENDING;
                                
                            #if (defined(SERIAL_ENABLE_MIDI_STREAMING) && (SERIAL_MIDI_IN_BUFF_SIZE > 0))
                                if ((pEP->bMisc == SERIAL_CLASS_AUDIO) && (epType == SERIAL_EP_TYPE_BULK))
                                {
                                    SERIAL_midi_in_ep = i;
                                }
                            #endif  /* (SERIAL_ENABLE_MIDI_STREAMING) */
                            }
                            else
                            {
                                /* OUT Endpoint */
                                SERIAL_EP[i].epMode     = SERIAL_GET_ACTIVE_OUT_EP_CR0_MODE(epType);
                                SERIAL_EP[i].apiEpState = SERIAL_NO_EVENT_PENDING;
                                
                            #if (defined(SERIAL_ENABLE_MIDI_STREAMING) && (SERIAL_MIDI_OUT_BUFF_SIZE > 0))
                                if ((pEP->bMisc == SERIAL_CLASS_AUDIO) && (epType == SERIAL_EP_TYPE_BULK))
                                {
                                    SERIAL_midi_out_ep = i;
                                }
                            #endif  /* (SERIAL_ENABLE_MIDI_STREAMING) */
                            }

                        #if (defined(SERIAL_ENABLE_CDC_CLASS))
                            if((pEP->bMisc == SERIAL_CLASS_CDC_DATA) ||(pEP->bMisc == SERIAL_CLASS_CDC))
                            {
                                cdcComNums = SERIAL_Cdc_EpInit(pEP, i, cdcComNums);
                            }
                        #endif  /* (SERIAL_ENABLE_CDC_CLASS) */

                            #if (SERIAL_EP_MANAGEMENT_DMA_AUTO)
                                break;  /* Use first EP setting in Auto memory management */
                            #endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO) */
                        }
                    }
                    
                    pEP = &pEP[1u];
                }
            }
        #endif /*  (SERIAL_EP_MANAGEMENT_MANUAL && SERIAL_EP_ALLOC_DYNAMIC) */

        /* Init class array for each interface and interface number for each EP.
        *  It is used for handling Class specific requests directed to either an
        *  interface or the endpoint.
        */
        /* p_list points the endpoint setting table. */
        pEP = (const T_SERIAL_EP_SETTINGS_BLOCK CYCODE *) pTmp->p_list;
        for (i = 0u; i < ep; i++)
        {
            /* Configure interface number for each EP */
            SERIAL_EP[pEP->addr & SERIAL_DIR_UNUSED].interface = pEP->interface;
            pEP = &pEP[1u];
        }
        
        /* Init pointer on interface class table */
        SERIAL_interfaceClass = SERIAL_GetInterfaceClassTablePtr();
        
    /* Set the endpoint buffer addresses */
    #if (!SERIAL_EP_MANAGEMENT_DMA_AUTO)
        buffCount = 0u;
        for (ep = SERIAL_EP1; ep < SERIAL_MAX_EP; ++ep)
        {
            SERIAL_EP[ep].buffOffset = buffCount;        
            buffCount += SERIAL_EP[ep].bufferSize;
            
        #if (SERIAL_GEN_16BITS_EP_ACCESS)
            /* Align EP buffers to be event size to access 16-bits DR register. */
            buffCount += (0u != (buffCount & 0x01u)) ? 1u : 0u;
        #endif /* (SERIAL_GEN_16BITS_EP_ACCESS) */            
        }
    #endif /* (!SERIAL_EP_MANAGEMENT_DMA_AUTO) */

        /* Configure hardware registers */
        SERIAL_ConfigReg();
    }
}


/*******************************************************************************
* Function Name: SERIAL_ConfigAltChanged
****************************************************************************//**
*
*  This routine update configuration for the required endpoints only.
*  It is called after SET_INTERFACE request when Static memory allocation used.
*
* \reentrant
*  No.
*
*******************************************************************************/
void SERIAL_ConfigAltChanged(void) 
{
    uint8 ep;
    uint8 curEp;
    uint8 epType;
    uint8 i;
    uint8 interfaceNum;

    const T_SERIAL_LUT CYCODE *pTmp;
    const T_SERIAL_EP_SETTINGS_BLOCK CYCODE *pEP;

    /* Init Endpoints and Device Status if configured */
    if (SERIAL_configuration > 0u)
    {
        /* Get number of endpoints configurations (ep). */
        pTmp = SERIAL_GetConfigTablePtr(SERIAL_configuration - 1u);
        pTmp = &pTmp[1u];
        ep = pTmp->c;

        /* Get pointer to endpoints setting table (pEP). */
        pEP = (const T_SERIAL_EP_SETTINGS_BLOCK CYCODE *) pTmp->p_list;
        
        /* Look through all possible endpoint configurations. Find endpoints 
        * which belong to current interface and alternate settings for 
        * re-configuration.
        */
        interfaceNum = SERIAL_interfaceNumber;
        for (i = 0u; i < ep; i++)
        {
            /* Find endpoints which belong to current interface and alternate settings. */
            if ((interfaceNum == pEP->interface) && 
                (SERIAL_interfaceSetting[interfaceNum] == pEP->altSetting))
            {
                curEp  = ((uint8) pEP->addr & SERIAL_DIR_UNUSED);
                epType = ((uint8) pEP->attributes & SERIAL_EP_TYPE_MASK);
                
                /* Change the SIE mode for the selected EP to NAK ALL */
                SERIAL_EP[curEp].epToggle   = 0u;
                SERIAL_EP[curEp].addr       = pEP->addr;
                SERIAL_EP[curEp].attrib     = pEP->attributes;
                SERIAL_EP[curEp].bufferSize = pEP->bufferSize;

                if (0u != (pEP->addr & SERIAL_DIR_IN))
                {
                    /* IN Endpoint */
                    SERIAL_EP[curEp].epMode     = SERIAL_GET_ACTIVE_IN_EP_CR0_MODE(epType);
                    SERIAL_EP[curEp].apiEpState = SERIAL_EVENT_PENDING;
                }
                else
                {
                    /* OUT Endpoint */
                    SERIAL_EP[curEp].epMode     = SERIAL_GET_ACTIVE_OUT_EP_CR0_MODE(epType);
                    SERIAL_EP[curEp].apiEpState = SERIAL_NO_EVENT_PENDING;
                }
                
                /* Make SIE to NAK any endpoint requests */
                SERIAL_SIE_EP_BASE.sieEp[curEp].epCr0 = SERIAL_MODE_NAK_IN_OUT;

            #if (SERIAL_EP_MANAGEMENT_DMA_AUTO)
                /* Clear IN data ready. */
                SERIAL_ARB_EP_BASE.arbEp[curEp].epCfg &= (uint8) ~SERIAL_ARB_EPX_CFG_IN_DATA_RDY;

                /* Select endpoint number of reconfiguration */
                SERIAL_DYN_RECONFIG_REG = (uint8) ((curEp - 1u) << SERIAL_DYN_RECONFIG_EP_SHIFT);
                
                /* Request for dynamic re-configuration of endpoint. */
                SERIAL_DYN_RECONFIG_REG |= SERIAL_DYN_RECONFIG_ENABLE;
                
                /* Wait until block is ready for re-configuration */
                while (0u == (SERIAL_DYN_RECONFIG_REG & SERIAL_DYN_RECONFIG_RDY_STS))
                {
                }
                
                /* Once DYN_RECONFIG_RDY_STS bit is set, FW can change the EP configuration. */
                /* Change EP Type with new direction */
                if (0u != (pEP->addr & SERIAL_DIR_IN))
                {
                    /* Set endpoint type: 0 - IN and 1 - OUT. */
                    SERIAL_EP_TYPE_REG &= (uint8) ~(uint8)((uint8) 0x01u << (curEp - 1u));
                    
                #if (CY_PSOC4)
                    /* Clear DMA_TERMIN for IN endpoint */
                    SERIAL_ARB_EP_BASE.arbEp[curEp].epIntEn &= (uint32) ~SERIAL_ARB_EPX_INT_DMA_TERMIN;
                #endif /* (CY_PSOC4) */
                }
                else
                {
                    /* Set endpoint type: 0 - IN and 1- OUT. */
                    SERIAL_EP_TYPE_REG |= (uint8) ((uint8) 0x01u << (curEp - 1u));
                    
                #if (CY_PSOC4)
                    /* Set DMA_TERMIN for OUT endpoint */
                    SERIAL_ARB_EP_BASE.arbEp[curEp].epIntEn |= (uint32) SERIAL_ARB_EPX_INT_DMA_TERMIN;
                #endif /* (CY_PSOC4) */
                }
                
                /* Complete dynamic re-configuration: all endpoint related status and signals 
                * are set into the default state.
                */
                SERIAL_DYN_RECONFIG_REG &= (uint8) ~SERIAL_DYN_RECONFIG_ENABLE;

            #else
                SERIAL_SIE_EP_BASE.sieEp[curEp].epCnt0 = HI8(SERIAL_EP[curEp].bufferSize);
                SERIAL_SIE_EP_BASE.sieEp[curEp].epCnt1 = LO8(SERIAL_EP[curEp].bufferSize);
                
                #if (CY_PSOC4)
                    SERIAL_ARB_EP16_BASE.arbEp[curEp].rwRa16  = (uint32) SERIAL_EP[curEp].buffOffset;
                    SERIAL_ARB_EP16_BASE.arbEp[curEp].rwWa16  = (uint32) SERIAL_EP[curEp].buffOffset;
                #else
                    SERIAL_ARB_EP_BASE.arbEp[curEp].rwRa    = LO8(SERIAL_EP[curEp].buffOffset);
                    SERIAL_ARB_EP_BASE.arbEp[curEp].rwRaMsb = HI8(SERIAL_EP[curEp].buffOffset);
                    SERIAL_ARB_EP_BASE.arbEp[curEp].rwWa    = LO8(SERIAL_EP[curEp].buffOffset);
                    SERIAL_ARB_EP_BASE.arbEp[curEp].rwWaMsb = HI8(SERIAL_EP[curEp].buffOffset);
                #endif /* (CY_PSOC4) */                
            #endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO) */
            }
            
            pEP = &pEP[1u]; /* Get next EP element */
        }
        
        /* The main loop has to re-enable DMA and OUT endpoint */
    }
}


/*******************************************************************************
* Function Name: SERIAL_GetConfigTablePtr
****************************************************************************//**
*
*  This routine returns a pointer a configuration table entry
*
*  \param confIndex:  Configuration Index
*
* \return
*  Device Descriptor pointer or NULL when descriptor does not exist.
*
*******************************************************************************/
const T_SERIAL_LUT CYCODE *SERIAL_GetConfigTablePtr(uint8 confIndex)
                                                        
{
    /* Device Table */
    const T_SERIAL_LUT CYCODE *pTmp;

    pTmp = (const T_SERIAL_LUT CYCODE *) SERIAL_TABLE[SERIAL_device].p_list;

    /* The first entry points to the Device Descriptor,
    *  the second entry point to the BOS Descriptor
    *  the rest configuration entries.
    *  Set pointer to the first Configuration Descriptor
    */
    pTmp = &pTmp[2u];
    /* For this table, c is the number of configuration descriptors  */
    if(confIndex >= pTmp->c)   /* Verify that required configuration descriptor exists */
    {
        pTmp = (const T_SERIAL_LUT CYCODE *) NULL;
    }
    else
    {
        pTmp = (const T_SERIAL_LUT CYCODE *) pTmp[confIndex].p_list;
    }

    return (pTmp);
}


#if (SERIAL_BOS_ENABLE)
    /*******************************************************************************
    * Function Name: SERIAL_GetBOSPtr
    ****************************************************************************//**
    *
    *  This routine returns a pointer a BOS table entry
    *
    *  
    *
    * \return
    *  BOS Descriptor pointer or NULL when descriptor does not exist.
    *
    *******************************************************************************/
    const T_SERIAL_LUT CYCODE *SERIAL_GetBOSPtr(void)
                                                            
    {
        /* Device Table */
        const T_SERIAL_LUT CYCODE *pTmp;

        pTmp = (const T_SERIAL_LUT CYCODE *) SERIAL_TABLE[SERIAL_device].p_list;

        /* The first entry points to the Device Descriptor,
        *  the second entry points to the BOS Descriptor
        */
        pTmp = &pTmp[1u];
        pTmp = (const T_SERIAL_LUT CYCODE *) pTmp->p_list;
        return (pTmp);
    }
#endif /* (SERIAL_BOS_ENABLE) */


/*******************************************************************************
* Function Name: SERIAL_GetDeviceTablePtr
****************************************************************************//**
*
*  This routine returns a pointer to the Device table
*
* \return
*  Device Table pointer
*
*******************************************************************************/
const T_SERIAL_LUT CYCODE *SERIAL_GetDeviceTablePtr(void)
                                                            
{
    /* Device Table */
    return( (const T_SERIAL_LUT CYCODE *) SERIAL_TABLE[SERIAL_device].p_list );
}


/*******************************************************************************
* Function Name: USB_GetInterfaceClassTablePtr
****************************************************************************//**
*
*  This routine returns Interface Class table pointer, which contains
*  the relation between interface number and interface class.
*
* \return
*  Interface Class table pointer.
*
*******************************************************************************/
const uint8 CYCODE *SERIAL_GetInterfaceClassTablePtr(void)
                                                        
{
    const T_SERIAL_LUT CYCODE *pTmp;
    const uint8 CYCODE *pInterfaceClass;
    uint8 currentInterfacesNum;

    pTmp = SERIAL_GetConfigTablePtr(SERIAL_configuration - 1u);
    if (pTmp != NULL)
    {
        currentInterfacesNum  = ((const uint8 *) pTmp->p_list)[SERIAL_CONFIG_DESCR_NUM_INTERFACES];
        /* Third entry in the LUT starts the Interface Table pointers */
        /* The INTERFACE_CLASS table is located after all interfaces */
        pTmp = &pTmp[currentInterfacesNum + 2u];
        pInterfaceClass = (const uint8 CYCODE *) pTmp->p_list;
    }
    else
    {
        pInterfaceClass = (const uint8 CYCODE *) NULL;
    }

    return (pInterfaceClass);
}


/*******************************************************************************
* Function Name: SERIAL_TerminateEP
****************************************************************************//**
*
*  This function terminates the specified USBFS endpoint.
*  This function should be used before endpoint reconfiguration.
*
*  \param ep Contains the data endpoint number.
*
*  \reentrant
*  No.
*
* \sideeffect
* 
* The device responds with a NAK for any transactions on the selected endpoint.
*   
*******************************************************************************/
void SERIAL_TerminateEP(uint8 epNumber) 
{
    /* Get endpoint number */
    epNumber &= SERIAL_DIR_UNUSED;

    if ((epNumber > SERIAL_EP0) && (epNumber < SERIAL_MAX_EP))
    {
        /* Set the endpoint Halt */
        SERIAL_EP[epNumber].hwEpState |= SERIAL_ENDPOINT_STATUS_HALT;

        /* Clear the data toggle */
        SERIAL_EP[epNumber].epToggle = 0u;
        SERIAL_EP[epNumber].apiEpState = SERIAL_NO_EVENT_ALLOWED;

        if ((SERIAL_EP[epNumber].addr & SERIAL_DIR_IN) != 0u)
        {   
            /* IN Endpoint */
            SERIAL_SIE_EP_BASE.sieEp[epNumber].epCr0 = SERIAL_MODE_NAK_IN;
        }
        else
        {
            /* OUT Endpoint */
            SERIAL_SIE_EP_BASE.sieEp[epNumber].epCr0 = SERIAL_MODE_NAK_OUT;
        }
    }
}


/*******************************************************************************
* Function Name: SERIAL_SetEndpointHalt
****************************************************************************//**
*
*  This routine handles set endpoint halt.
*
* \return
*  requestHandled.
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 SERIAL_SetEndpointHalt(void) 
{
    uint8 requestHandled = SERIAL_FALSE;
    uint8 ep;
    
    /* Set endpoint halt */
    ep = SERIAL_wIndexLoReg & SERIAL_DIR_UNUSED;

    if ((ep > SERIAL_EP0) && (ep < SERIAL_MAX_EP))
    {
        /* Set the endpoint Halt */
        SERIAL_EP[ep].hwEpState |= (SERIAL_ENDPOINT_STATUS_HALT);

        /* Clear the data toggle */
        SERIAL_EP[ep].epToggle = 0u;
        SERIAL_EP[ep].apiEpState |= SERIAL_NO_EVENT_ALLOWED;

        if ((SERIAL_EP[ep].addr & SERIAL_DIR_IN) != 0u)
        {
            /* IN Endpoint */
            SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = (SERIAL_MODE_STALL_DATA_EP | 
                                                            SERIAL_MODE_ACK_IN);
        }
        else
        {
            /* OUT Endpoint */
            SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = (SERIAL_MODE_STALL_DATA_EP | 
                                                            SERIAL_MODE_ACK_OUT);
        }
        requestHandled = SERIAL_InitNoDataControlTransfer();
    }

    return (requestHandled);
}


/*******************************************************************************
* Function Name: SERIAL_ClearEndpointHalt
****************************************************************************//**
*
*  This routine handles clear endpoint halt.
*
* \return
*  requestHandled.
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 SERIAL_ClearEndpointHalt(void) 
{
    uint8 requestHandled = SERIAL_FALSE;
    uint8 ep;

    /* Clear endpoint halt */
    ep = SERIAL_wIndexLoReg & SERIAL_DIR_UNUSED;

    if ((ep > SERIAL_EP0) && (ep < SERIAL_MAX_EP))
    {
        /* Clear the endpoint Halt */
        SERIAL_EP[ep].hwEpState &= (uint8) ~SERIAL_ENDPOINT_STATUS_HALT;

        /* Clear the data toggle */
        SERIAL_EP[ep].epToggle = 0u;
        
        /* Clear toggle bit for already armed packet */
        SERIAL_SIE_EP_BASE.sieEp[ep].epCnt0 &= (uint8) ~(uint8)SERIAL_EPX_CNT_DATA_TOGGLE;
        
        /* Return API State as it was defined before */
        SERIAL_EP[ep].apiEpState &= (uint8) ~SERIAL_NO_EVENT_ALLOWED;

        if ((SERIAL_EP[ep].addr & SERIAL_DIR_IN) != 0u)
        {
            /* IN Endpoint */
            if(SERIAL_EP[ep].apiEpState == SERIAL_IN_BUFFER_EMPTY)
            {       
                /* Wait for next packet from application */
                SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = SERIAL_MODE_NAK_IN;
            }
            else    /* Continue armed transfer */
            {
                SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = SERIAL_MODE_ACK_IN;
            }
        }
        else
        {
            /* OUT Endpoint */
            if (SERIAL_EP[ep].apiEpState == SERIAL_OUT_BUFFER_FULL)
            {       
                /* Allow application to read full buffer */
                SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = SERIAL_MODE_NAK_OUT;
            }
            else    /* Mark endpoint as empty, so it will be reloaded */
            {
                SERIAL_SIE_EP_BASE.sieEp[ep].epCr0 = SERIAL_MODE_ACK_OUT;
            }
        }
        
        requestHandled = SERIAL_InitNoDataControlTransfer();
    }

    return(requestHandled);
}


/*******************************************************************************
* Function Name: SERIAL_ValidateAlternateSetting
****************************************************************************//**
*
*  Validates (and records) a SET INTERFACE request.
*
* \return
*  requestHandled.
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 SERIAL_ValidateAlternateSetting(void) 
{
    uint8 requestHandled = SERIAL_FALSE;
    
    uint8 interfaceNum;
    uint8 curInterfacesNum;
    const T_SERIAL_LUT CYCODE *pTmp;
    
    /* Get interface number from the request. */
    interfaceNum = (uint8) SERIAL_wIndexLoReg;
    
    /* Get number of interfaces for current configuration. */
    pTmp = SERIAL_GetConfigTablePtr(SERIAL_configuration - 1u);
    curInterfacesNum  = ((const uint8 *) pTmp->p_list)[SERIAL_CONFIG_DESCR_NUM_INTERFACES];

    /* Validate that interface number is within range. */
    if ((interfaceNum <= curInterfacesNum) || (interfaceNum <= SERIAL_MAX_INTERFACES_NUMBER))
    {
        /* Save current and new alternate settings (come with request) to make 
        * desicion about following endpoint re-configuration.
        */
        SERIAL_interfaceSettingLast[interfaceNum] = SERIAL_interfaceSetting[interfaceNum];
        SERIAL_interfaceSetting[interfaceNum]     = (uint8) SERIAL_wValueLoReg;
        
        requestHandled = SERIAL_TRUE;
    }

    return (requestHandled);
}


/* [] END OF FILE */
