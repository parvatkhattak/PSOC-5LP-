/***************************************************************************//**
* \file SERIAL_vnd.c
* \version 3.20
*
* \brief
*  This file contains the  USB vendor request handler.
*
********************************************************************************
* \copyright
* Copyright 2008-2016, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SERIAL_pvt.h"
#include "cyapicallbacks.h"

#if(SERIAL_EXTERN_VND == SERIAL_FALSE)

/***************************************
* Vendor Specific Declarations
***************************************/

/* `#START VENDOR_SPECIFIC_DECLARATIONS` Place your declaration here */

/* `#END` */


/*******************************************************************************
* Function Name: SERIAL_HandleVendorRqst
****************************************************************************//**
*
*  This routine provide users with a method to implement vendor specific
*  requests.
*
*  To implement vendor specific requests, add your code in this function to
*  decode and disposition the request.  If the request is handled, your code
*  must set the variable "requestHandled" to TRUE, indicating that the
*  request has been handled.
*
* \return
*  requestHandled.
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 SERIAL_HandleVendorRqst(void) 
{
    uint8 requestHandled = SERIAL_FALSE;

    /* Check request direction: D2H or H2D. */
    if (0u != (SERIAL_bmRequestTypeReg & SERIAL_RQST_DIR_D2H))
    {
        /* Handle direction from device to host. */
        
        switch (SERIAL_bRequestReg)
        {
            case SERIAL_GET_EXTENDED_CONFIG_DESCRIPTOR:
            #if defined(SERIAL_ENABLE_MSOS_STRING)
                SERIAL_currentTD.pData = (volatile uint8 *) &SERIAL_MSOS_CONFIGURATION_DESCR[0u];
                SERIAL_currentTD.count = SERIAL_MSOS_CONFIGURATION_DESCR[0u];
                requestHandled  = SERIAL_InitControlRead();
            #endif /* (SERIAL_ENABLE_MSOS_STRING) */
                break;
            
            default:
                break;
        }
    }

    /* `#START VENDOR_SPECIFIC_CODE` Place your vendor specific request here */

    /* `#END` */

#ifdef SERIAL_HANDLE_VENDOR_RQST_CALLBACK
    if (SERIAL_FALSE == requestHandled)
    {
        requestHandled = SERIAL_HandleVendorRqst_Callback();
    }
#endif /* (SERIAL_HANDLE_VENDOR_RQST_CALLBACK) */

    return (requestHandled);
}


/*******************************************************************************
* Additional user functions supporting Vendor Specific Requests
********************************************************************************/

/* `#START VENDOR_SPECIFIC_FUNCTIONS` Place any additional functions here */

/* `#END` */


#endif /* SERIAL_EXTERN_VND */


/* [] END OF FILE */
