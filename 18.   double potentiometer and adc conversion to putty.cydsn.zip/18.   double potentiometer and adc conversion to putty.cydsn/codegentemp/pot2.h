/*******************************************************************************
* File Name: pot2.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_pot2_H) /* Pins pot2_H */
#define CY_PINS_pot2_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "pot2_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 pot2__PORT == 15 && ((pot2__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    pot2_Write(uint8 value);
void    pot2_SetDriveMode(uint8 mode);
uint8   pot2_ReadDataReg(void);
uint8   pot2_Read(void);
void    pot2_SetInterruptMode(uint16 position, uint16 mode);
uint8   pot2_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the pot2_SetDriveMode() function.
     *  @{
     */
        #define pot2_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define pot2_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define pot2_DM_RES_UP          PIN_DM_RES_UP
        #define pot2_DM_RES_DWN         PIN_DM_RES_DWN
        #define pot2_DM_OD_LO           PIN_DM_OD_LO
        #define pot2_DM_OD_HI           PIN_DM_OD_HI
        #define pot2_DM_STRONG          PIN_DM_STRONG
        #define pot2_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define pot2_MASK               pot2__MASK
#define pot2_SHIFT              pot2__SHIFT
#define pot2_WIDTH              1u

/* Interrupt constants */
#if defined(pot2__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in pot2_SetInterruptMode() function.
     *  @{
     */
        #define pot2_INTR_NONE      (uint16)(0x0000u)
        #define pot2_INTR_RISING    (uint16)(0x0001u)
        #define pot2_INTR_FALLING   (uint16)(0x0002u)
        #define pot2_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define pot2_INTR_MASK      (0x01u) 
#endif /* (pot2__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define pot2_PS                     (* (reg8 *) pot2__PS)
/* Data Register */
#define pot2_DR                     (* (reg8 *) pot2__DR)
/* Port Number */
#define pot2_PRT_NUM                (* (reg8 *) pot2__PRT) 
/* Connect to Analog Globals */                                                  
#define pot2_AG                     (* (reg8 *) pot2__AG)                       
/* Analog MUX bux enable */
#define pot2_AMUX                   (* (reg8 *) pot2__AMUX) 
/* Bidirectional Enable */                                                        
#define pot2_BIE                    (* (reg8 *) pot2__BIE)
/* Bit-mask for Aliased Register Access */
#define pot2_BIT_MASK               (* (reg8 *) pot2__BIT_MASK)
/* Bypass Enable */
#define pot2_BYP                    (* (reg8 *) pot2__BYP)
/* Port wide control signals */                                                   
#define pot2_CTL                    (* (reg8 *) pot2__CTL)
/* Drive Modes */
#define pot2_DM0                    (* (reg8 *) pot2__DM0) 
#define pot2_DM1                    (* (reg8 *) pot2__DM1)
#define pot2_DM2                    (* (reg8 *) pot2__DM2) 
/* Input Buffer Disable Override */
#define pot2_INP_DIS                (* (reg8 *) pot2__INP_DIS)
/* LCD Common or Segment Drive */
#define pot2_LCD_COM_SEG            (* (reg8 *) pot2__LCD_COM_SEG)
/* Enable Segment LCD */
#define pot2_LCD_EN                 (* (reg8 *) pot2__LCD_EN)
/* Slew Rate Control */
#define pot2_SLW                    (* (reg8 *) pot2__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define pot2_PRTDSI__CAPS_SEL       (* (reg8 *) pot2__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define pot2_PRTDSI__DBL_SYNC_IN    (* (reg8 *) pot2__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define pot2_PRTDSI__OE_SEL0        (* (reg8 *) pot2__PRTDSI__OE_SEL0) 
#define pot2_PRTDSI__OE_SEL1        (* (reg8 *) pot2__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define pot2_PRTDSI__OUT_SEL0       (* (reg8 *) pot2__PRTDSI__OUT_SEL0) 
#define pot2_PRTDSI__OUT_SEL1       (* (reg8 *) pot2__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define pot2_PRTDSI__SYNC_OUT       (* (reg8 *) pot2__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(pot2__SIO_CFG)
    #define pot2_SIO_HYST_EN        (* (reg8 *) pot2__SIO_HYST_EN)
    #define pot2_SIO_REG_HIFREQ     (* (reg8 *) pot2__SIO_REG_HIFREQ)
    #define pot2_SIO_CFG            (* (reg8 *) pot2__SIO_CFG)
    #define pot2_SIO_DIFF           (* (reg8 *) pot2__SIO_DIFF)
#endif /* (pot2__SIO_CFG) */

/* Interrupt Registers */
#if defined(pot2__INTSTAT)
    #define pot2_INTSTAT            (* (reg8 *) pot2__INTSTAT)
    #define pot2_SNAP               (* (reg8 *) pot2__SNAP)
    
	#define pot2_0_INTTYPE_REG 		(* (reg8 *) pot2__0__INTTYPE)
#endif /* (pot2__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_pot2_H */


/* [] END OF FILE */
