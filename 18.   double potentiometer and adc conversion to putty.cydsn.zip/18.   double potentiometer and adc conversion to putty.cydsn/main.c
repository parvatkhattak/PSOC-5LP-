/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include<stdio.h>
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    USBUART_Start(0,USBUART_5V_OPERATION);
    while(USBUART_GetConfiguration()==0){}
    
    ADC_SAR_Start();
    ADC_SAR_StartConvert();
    AMux_Start();
   
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
   
    for(;;)
    {
        /* Place your application code here. */
        AMux_Select(0);
        int pot1= ADC_SAR_GetResult16();
        AMux_Select(1);
        int pot2= ADC_SAR_GetResult16();
        char send[100];
        sprintf(send,"pot1:%d,pot2:%d\r\n",pot1,pot2);
        USBUART_PutString(send);
        CyDelay(100);
        
       
    }
}

/* [] END OF FILE */
