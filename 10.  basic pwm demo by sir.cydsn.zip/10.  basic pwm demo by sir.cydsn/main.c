/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
int i=0;
CY_ISR(pwm)
{
    PWM_WriteCompare(i);
    i++;
    if (i==100){
        i=0;
    }
    
    
    
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    PWM_Start();
    isr_1_StartEx(pwm);

    for(;;)
    {
        /* Place your application code here. */
        
    }
}

/* [] END OF FILE */
