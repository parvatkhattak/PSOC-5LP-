/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include<stdio.h>
# define pwm_max 1999
# define pwm_min 0
# define dir_up 0
# define dir_down 1

volatile uint16_t Interrupt=0;
volatile uint8_t dir=0;

CY_ISR(Timer_Int)
{
    Timer_STATUS;
    if (dir==dir_up){
        Interrupt+=5;
        if (Interrupt>=pwm_max){
            dir=dir_down;
        }
    }
    else {
        Interrupt-=5;
        if (Interrupt<=pwm_min){
            dir=dir_up;
        }
    }
    PWM_WriteCompare(Interrupt);
    uint16 interrupt;
    interrupt=ADC_SAR_GetResult16();
    char send[100];
    sprintf(send,"%d\r\n",interrupt);
    USBUART_PutString(send);
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    USBUART_Start(0,USBUART_5V_OPERATION);
    while(USBUART_GetConfiguration()==0){}
    
    ADC_SAR_Start();
    ADC_SAR_StartConvert();
    isr_1_ClearPending();
    isr_1_StartEx(Timer_Int);
    PWM_Start();
    Timer_Start();
    
   
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
   
    for(;;)
    {
        /* Place your application code here. */
        
       
    }
}

/* [] END OF FILE */
