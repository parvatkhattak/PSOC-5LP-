/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
int val=0;
int dir=0;
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    PWM_Start();

    for(;;)
    {
        /* Place your application code here. */
        if (dir==0) {
            val++;
        }
        else {
            val--;
        }
        
        if (val>=100) {
            dir=1;
        }
        else if ( val<=0) {
            dir=0;
        }
        PWM_WriteCompare(val);
        CyDelay(2);
        
    }
}

/* [] END OF FILE */
