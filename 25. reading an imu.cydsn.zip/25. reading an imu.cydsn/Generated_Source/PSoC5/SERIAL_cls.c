/***************************************************************************//**
* \file SERIAL_cls.c
* \version 3.20
*
* \brief
*  This file contains the USB Class request handler.
*
********************************************************************************
* \copyright
* Copyright 2008-2016, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SERIAL_pvt.h"
#include "cyapicallbacks.h"

#if(SERIAL_EXTERN_CLS == SERIAL_FALSE)

/***************************************
* User Implemented Class Driver Declarations.
***************************************/
/* `#START USER_DEFINED_CLASS_DECLARATIONS` Place your declaration here */

/* `#END` */


/*******************************************************************************
* Function Name: SERIAL_DispatchClassRqst
****************************************************************************//**
*  This routine dispatches class specific requests depend on interface class.
*
* \return
*  requestHandled.
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 SERIAL_DispatchClassRqst(void) 
{
    uint8 interfaceNumber;
    uint8 requestHandled = SERIAL_FALSE;

    /* Get interface to which request is intended. */
    switch (SERIAL_bmRequestTypeReg & SERIAL_RQST_RCPT_MASK)
    {
        case SERIAL_RQST_RCPT_IFC:
            /* Class-specific request directed to interface: wIndexLoReg 
            * contains interface number.
            */
            interfaceNumber = (uint8) SERIAL_wIndexLoReg;
            break;
        
        case SERIAL_RQST_RCPT_EP:
            /* Class-specific request directed to endpoint: wIndexLoReg contains 
            * endpoint number. Find interface related to endpoint. 
            */
            interfaceNumber = SERIAL_EP[SERIAL_wIndexLoReg & SERIAL_DIR_UNUSED].interface;
            break;
            
        default:
            /* Default interface is zero. */
            interfaceNumber = 0u;
            break;
    }
    
    /* Check that interface is within acceptable range */
    if (interfaceNumber <= SERIAL_MAX_INTERFACES_NUMBER)
    {
    #if (defined(SERIAL_ENABLE_HID_CLASS)   || \
         defined(SERIAL_ENABLE_AUDIO_CLASS) || \
         defined(SERIAL_ENABLE_CDC_CLASS)   || \
         SERIAL_ENABLE_MSC_CLASS)

        /* Handle class request depends on interface type. */
        switch (SERIAL_interfaceClass[interfaceNumber])
        {
        #if defined(SERIAL_ENABLE_HID_CLASS)
            case SERIAL_CLASS_HID:
                requestHandled = SERIAL_DispatchHIDClassRqst();
                break;
        #endif /* (SERIAL_ENABLE_HID_CLASS) */
                
        #if defined(SERIAL_ENABLE_AUDIO_CLASS)
            case SERIAL_CLASS_AUDIO:
                requestHandled = SERIAL_DispatchAUDIOClassRqst();
                break;
        #endif /* (SERIAL_CLASS_AUDIO) */
                
        #if defined(SERIAL_ENABLE_CDC_CLASS)
            case SERIAL_CLASS_CDC:
                requestHandled = SERIAL_DispatchCDCClassRqst();
                break;
        #endif /* (SERIAL_ENABLE_CDC_CLASS) */
            
        #if (SERIAL_ENABLE_MSC_CLASS)
            case SERIAL_CLASS_MSD:
            #if (SERIAL_HANDLE_MSC_REQUESTS)
                /* MSC requests are handled by the component. */
                requestHandled = SERIAL_DispatchMSCClassRqst();
            #elif defined(SERIAL_DISPATCH_MSC_CLASS_RQST_CALLBACK)
                /* MSC requests are handled by user defined callbcak. */
                requestHandled = SERIAL_DispatchMSCClassRqst_Callback();
            #else
                /* MSC requests are not handled. */
                requestHandled = SERIAL_FALSE;
            #endif /* (SERIAL_HANDLE_MSC_REQUESTS) */
                break;
        #endif /* (SERIAL_ENABLE_MSC_CLASS) */
            
            default:
                /* Request is not handled: unknown class request type. */
                requestHandled = SERIAL_FALSE;
                break;
        }
    #endif /* Class support is enabled */
    }
    
    /* `#START USER_DEFINED_CLASS_CODE` Place your Class request here */

    /* `#END` */

#ifdef SERIAL_DISPATCH_CLASS_RQST_CALLBACK
    if (SERIAL_FALSE == requestHandled)
    {
        requestHandled = SERIAL_DispatchClassRqst_Callback(interfaceNumber);
    }
#endif /* (SERIAL_DISPATCH_CLASS_RQST_CALLBACK) */

    return (requestHandled);
}


/*******************************************************************************
* Additional user functions supporting Class Specific Requests
********************************************************************************/

/* `#START CLASS_SPECIFIC_FUNCTIONS` Place any additional functions here */

/* `#END` */

#endif /* SERIAL_EXTERN_CLS */


/* [] END OF FILE */
