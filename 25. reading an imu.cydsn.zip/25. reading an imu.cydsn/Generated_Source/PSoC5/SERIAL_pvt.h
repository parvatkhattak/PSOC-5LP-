/***************************************************************************//**
* \file .h
* \version 3.20
*
* \brief
*  This file provides private function prototypes and constants for the 
*  USBFS component. It is not intended to be used in the user project.
*
********************************************************************************
* \copyright
* Copyright 2013-2016, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_USBFS_SERIAL_pvt_H)
#define CY_USBFS_SERIAL_pvt_H

#include "SERIAL.h"
   
#ifdef SERIAL_ENABLE_AUDIO_CLASS
    #include "SERIAL_audio.h"
#endif /* SERIAL_ENABLE_AUDIO_CLASS */

#ifdef SERIAL_ENABLE_CDC_CLASS
    #include "SERIAL_cdc.h"
#endif /* SERIAL_ENABLE_CDC_CLASS */

#if (SERIAL_ENABLE_MIDI_CLASS)
    #include "SERIAL_midi.h"
#endif /* (SERIAL_ENABLE_MIDI_CLASS) */

#if (SERIAL_ENABLE_MSC_CLASS)
    #include "SERIAL_msc.h"
#endif /* (SERIAL_ENABLE_MSC_CLASS) */

#if (SERIAL_EP_MANAGEMENT_DMA)
    #if (CY_PSOC4)
        #include <CyDMA.h>
    #else
        #include <CyDmac.h>
        #if ((SERIAL_EP_MANAGEMENT_DMA_AUTO) && (SERIAL_EP_DMA_AUTO_OPT == 0u))
            #include "SERIAL_EP_DMA_Done_isr.h"
            #include "SERIAL_EP8_DMA_Done_SR.h"
            #include "SERIAL_EP17_DMA_Done_SR.h"
        #endif /* ((SERIAL_EP_MANAGEMENT_DMA_AUTO) && (SERIAL_EP_DMA_AUTO_OPT == 0u)) */
    #endif /* (CY_PSOC4) */
#endif /* (SERIAL_EP_MANAGEMENT_DMA) */

#if (SERIAL_DMA1_ACTIVE)
    #include "SERIAL_ep1_dma.h"
    #define SERIAL_EP1_DMA_CH     (SERIAL_ep1_dma_CHANNEL)
#endif /* (SERIAL_DMA1_ACTIVE) */

#if (SERIAL_DMA2_ACTIVE)
    #include "SERIAL_ep2_dma.h"
    #define SERIAL_EP2_DMA_CH     (SERIAL_ep2_dma_CHANNEL)
#endif /* (SERIAL_DMA2_ACTIVE) */

#if (SERIAL_DMA3_ACTIVE)
    #include "SERIAL_ep3_dma.h"
    #define SERIAL_EP3_DMA_CH     (SERIAL_ep3_dma_CHANNEL)
#endif /* (SERIAL_DMA3_ACTIVE) */

#if (SERIAL_DMA4_ACTIVE)
    #include "SERIAL_ep4_dma.h"
    #define SERIAL_EP4_DMA_CH     (SERIAL_ep4_dma_CHANNEL)
#endif /* (SERIAL_DMA4_ACTIVE) */

#if (SERIAL_DMA5_ACTIVE)
    #include "SERIAL_ep5_dma.h"
    #define SERIAL_EP5_DMA_CH     (SERIAL_ep5_dma_CHANNEL)
#endif /* (SERIAL_DMA5_ACTIVE) */

#if (SERIAL_DMA6_ACTIVE)
    #include "SERIAL_ep6_dma.h"
    #define SERIAL_EP6_DMA_CH     (SERIAL_ep6_dma_CHANNEL)
#endif /* (SERIAL_DMA6_ACTIVE) */

#if (SERIAL_DMA7_ACTIVE)
    #include "SERIAL_ep7_dma.h"
    #define SERIAL_EP7_DMA_CH     (SERIAL_ep7_dma_CHANNEL)
#endif /* (SERIAL_DMA7_ACTIVE) */

#if (SERIAL_DMA8_ACTIVE)
    #include "SERIAL_ep8_dma.h"
    #define SERIAL_EP8_DMA_CH     (SERIAL_ep8_dma_CHANNEL)
#endif /* (SERIAL_DMA8_ACTIVE) */


/***************************************
*     Private Variables
***************************************/

/* Generated external references for descriptors. */
extern const uint8 CYCODE SERIAL_DEVICE0_DESCR[18u];
extern const uint8 CYCODE SERIAL_DEVICE0_CONFIGURATION0_DESCR[67u];
extern const T_SERIAL_EP_SETTINGS_BLOCK CYCODE SERIAL_DEVICE0_CONFIGURATION0_EP_SETTINGS_TABLE[3u];
extern const uint8 CYCODE SERIAL_DEVICE0_CONFIGURATION0_INTERFACE_CLASS[2u];
extern const T_SERIAL_LUT CYCODE SERIAL_DEVICE0_CONFIGURATION0_TABLE[5u];
extern const T_SERIAL_LUT CYCODE SERIAL_DEVICE0_TABLE[3u];
extern const T_SERIAL_LUT CYCODE SERIAL_TABLE[1u];
extern const uint8 CYCODE SERIAL_SN_STRING_DESCRIPTOR[2];
extern const uint8 CYCODE SERIAL_STRING_DESCRIPTORS[159u];


extern const uint8 CYCODE SERIAL_MSOS_DESCRIPTOR[SERIAL_MSOS_DESCRIPTOR_LENGTH];
extern const uint8 CYCODE SERIAL_MSOS_CONFIGURATION_DESCR[SERIAL_MSOS_CONF_DESCR_LENGTH];
#if defined(SERIAL_ENABLE_IDSN_STRING)
    extern uint8 SERIAL_idSerialNumberStringDescriptor[SERIAL_IDSN_DESCR_LENGTH];
#endif /* (SERIAL_ENABLE_IDSN_STRING) */

extern volatile uint8 SERIAL_interfaceNumber;
extern volatile uint8 SERIAL_interfaceSetting[SERIAL_MAX_INTERFACES_NUMBER];
extern volatile uint8 SERIAL_interfaceSettingLast[SERIAL_MAX_INTERFACES_NUMBER];
extern volatile uint8 SERIAL_deviceAddress;
extern volatile uint8 SERIAL_interfaceStatus[SERIAL_MAX_INTERFACES_NUMBER];
extern const uint8 CYCODE *SERIAL_interfaceClass;

extern volatile T_SERIAL_EP_CTL_BLOCK SERIAL_EP[SERIAL_MAX_EP];
extern volatile T_SERIAL_TD SERIAL_currentTD;

#if (SERIAL_EP_MANAGEMENT_DMA)
    #if (CY_PSOC4)
        extern const uint8 SERIAL_DmaChan[SERIAL_MAX_EP];
    #else
        extern uint8 SERIAL_DmaChan[SERIAL_MAX_EP];
        extern uint8 SERIAL_DmaTd  [SERIAL_MAX_EP];
    #endif /* (CY_PSOC4) */
#endif /* (SERIAL_EP_MANAGEMENT_DMA) */

#if (SERIAL_EP_MANAGEMENT_DMA_AUTO)
#if (CY_PSOC4)
    extern uint8  SERIAL_DmaEpBurstCnt   [SERIAL_MAX_EP];
    extern uint8  SERIAL_DmaEpLastBurstEl[SERIAL_MAX_EP];

    extern uint8  SERIAL_DmaEpBurstCntBackup  [SERIAL_MAX_EP];
    extern uint32 SERIAL_DmaEpBufferAddrBackup[SERIAL_MAX_EP];
    
    extern const uint8 SERIAL_DmaReqOut     [SERIAL_MAX_EP];    
    extern const uint8 SERIAL_DmaBurstEndOut[SERIAL_MAX_EP];
#else
    #if (SERIAL_EP_DMA_AUTO_OPT == 0u)
        extern uint8 SERIAL_DmaNextTd[SERIAL_MAX_EP];
        extern volatile uint16 SERIAL_inLength [SERIAL_MAX_EP];
        extern volatile uint8  SERIAL_inBufFull[SERIAL_MAX_EP];
        extern const uint8 SERIAL_epX_TD_TERMOUT_EN[SERIAL_MAX_EP];
        extern const uint8 *SERIAL_inDataPointer[SERIAL_MAX_EP];
    #endif /* (SERIAL_EP_DMA_AUTO_OPT == 0u) */
#endif /* CY_PSOC4 */
#endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO) */

extern volatile uint8 SERIAL_ep0Toggle;
extern volatile uint8 SERIAL_lastPacketSize;
extern volatile uint8 SERIAL_ep0Mode;
extern volatile uint8 SERIAL_ep0Count;
extern volatile uint16 SERIAL_transferByteCount;


/***************************************
*     Private Function Prototypes
***************************************/
void  SERIAL_ReInitComponent(void)            ;
void  SERIAL_HandleSetup(void)                ;
void  SERIAL_HandleIN(void)                   ;
void  SERIAL_HandleOUT(void)                  ;
void  SERIAL_LoadEP0(void)                    ;
uint8 SERIAL_InitControlRead(void)            ;
uint8 SERIAL_InitControlWrite(void)           ;
void  SERIAL_ControlReadDataStage(void)       ;
void  SERIAL_ControlReadStatusStage(void)     ;
void  SERIAL_ControlReadPrematureStatus(void) ;
uint8 SERIAL_InitControlWrite(void)           ;
uint8 SERIAL_InitZeroLengthControlTransfer(void) ;
void  SERIAL_ControlWriteDataStage(void)      ;
void  SERIAL_ControlWriteStatusStage(void)    ;
void  SERIAL_ControlWritePrematureStatus(void);
uint8 SERIAL_InitNoDataControlTransfer(void)  ;
void  SERIAL_NoDataControlStatusStage(void)   ;
void  SERIAL_InitializeStatusBlock(void)      ;
void  SERIAL_UpdateStatusBlock(uint8 completionCode) ;
uint8 SERIAL_DispatchClassRqst(void)          ;

void SERIAL_Config(uint8 clearAltSetting) ;
void SERIAL_ConfigAltChanged(void)        ;
void SERIAL_ConfigReg(void)               ;
void SERIAL_EpStateInit(void)             ;


const T_SERIAL_LUT CYCODE *SERIAL_GetConfigTablePtr(uint8 confIndex);
const T_SERIAL_LUT CYCODE *SERIAL_GetDeviceTablePtr(void)           ;
#if (SERIAL_BOS_ENABLE)
    const T_SERIAL_LUT CYCODE *SERIAL_GetBOSPtr(void)               ;
#endif /* (SERIAL_BOS_ENABLE) */
const uint8 CYCODE *SERIAL_GetInterfaceClassTablePtr(void)                    ;
uint8 SERIAL_ClearEndpointHalt(void)                                          ;
uint8 SERIAL_SetEndpointHalt(void)                                            ;
uint8 SERIAL_ValidateAlternateSetting(void)                                   ;

void SERIAL_SaveConfig(void)      ;
void SERIAL_RestoreConfig(void)   ;

#if (CY_PSOC3 || CY_PSOC5LP)
    #if (SERIAL_EP_MANAGEMENT_DMA_AUTO && (SERIAL_EP_DMA_AUTO_OPT == 0u))
        void SERIAL_LoadNextInEP(uint8 epNumber, uint8 mode)  ;
    #endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO && (SERIAL_EP_DMA_AUTO_OPT == 0u)) */
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

#if defined(SERIAL_ENABLE_IDSN_STRING)
    void SERIAL_ReadDieID(uint8 descr[])  ;
#endif /* SERIAL_ENABLE_IDSN_STRING */

#if defined(SERIAL_ENABLE_HID_CLASS)
    uint8 SERIAL_DispatchHIDClassRqst(void) ;
#endif /* (SERIAL_ENABLE_HID_CLASS) */

#if defined(SERIAL_ENABLE_AUDIO_CLASS)
    uint8 SERIAL_DispatchAUDIOClassRqst(void) ;
#endif /* (SERIAL_ENABLE_AUDIO_CLASS) */

#if defined(SERIAL_ENABLE_CDC_CLASS)
    uint8 SERIAL_DispatchCDCClassRqst(void) ;
#endif /* (SERIAL_ENABLE_CDC_CLASS) */

#if (SERIAL_ENABLE_MSC_CLASS)
    #if (SERIAL_HANDLE_MSC_REQUESTS)
        uint8 SERIAL_DispatchMSCClassRqst(void) ;
    #endif /* (SERIAL_HANDLE_MSC_REQUESTS) */
#endif /* (SERIAL_ENABLE_MSC_CLASS */

CY_ISR_PROTO(SERIAL_EP_0_ISR);
CY_ISR_PROTO(SERIAL_BUS_RESET_ISR);

#if (SERIAL_SOF_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_SOF_ISR);
#endif /* (SERIAL_SOF_ISR_ACTIVE) */

#if (SERIAL_EP1_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_EP_1_ISR);
#endif /* (SERIAL_EP1_ISR_ACTIVE) */

#if (SERIAL_EP2_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_EP_2_ISR);
#endif /* (SERIAL_EP2_ISR_ACTIVE) */

#if (SERIAL_EP3_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_EP_3_ISR);
#endif /* (SERIAL_EP3_ISR_ACTIVE) */

#if (SERIAL_EP4_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_EP_4_ISR);
#endif /* (SERIAL_EP4_ISR_ACTIVE) */

#if (SERIAL_EP5_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_EP_5_ISR);
#endif /* (SERIAL_EP5_ISR_ACTIVE) */

#if (SERIAL_EP6_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_EP_6_ISR);
#endif /* (SERIAL_EP6_ISR_ACTIVE) */

#if (SERIAL_EP7_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_EP_7_ISR);
#endif /* (SERIAL_EP7_ISR_ACTIVE) */

#if (SERIAL_EP8_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_EP_8_ISR);
#endif /* (SERIAL_EP8_ISR_ACTIVE) */

#if (SERIAL_EP_MANAGEMENT_DMA)
    CY_ISR_PROTO(SERIAL_ARB_ISR);
#endif /* (SERIAL_EP_MANAGEMENT_DMA) */

#if (SERIAL_DP_ISR_ACTIVE)
    CY_ISR_PROTO(SERIAL_DP_ISR);
#endif /* (SERIAL_DP_ISR_ACTIVE) */

#if (CY_PSOC4)
    CY_ISR_PROTO(SERIAL_INTR_HI_ISR);
    CY_ISR_PROTO(SERIAL_INTR_MED_ISR);
    CY_ISR_PROTO(SERIAL_INTR_LO_ISR);
    #if (SERIAL_LPM_ACTIVE)
        CY_ISR_PROTO(SERIAL_LPM_ISR);
    #endif /* (SERIAL_LPM_ACTIVE) */
#endif /* (CY_PSOC4) */

#if (SERIAL_EP_MANAGEMENT_DMA_AUTO)
#if (CY_PSOC4)
    #if (SERIAL_DMA1_ACTIVE)
        void SERIAL_EP1_DMA_DONE_ISR(void);
    #endif /* (SERIAL_DMA1_ACTIVE) */

    #if (SERIAL_DMA2_ACTIVE)
        void SERIAL_EP2_DMA_DONE_ISR(void);
    #endif /* (SERIAL_DMA2_ACTIVE) */

    #if (SERIAL_DMA3_ACTIVE)
        void SERIAL_EP3_DMA_DONE_ISR(void);
    #endif /* (SERIAL_DMA3_ACTIVE) */

    #if (SERIAL_DMA4_ACTIVE)
        void SERIAL_EP4_DMA_DONE_ISR(void);
    #endif /* (SERIAL_DMA4_ACTIVE) */

    #if (SERIAL_DMA5_ACTIVE)
        void SERIAL_EP5_DMA_DONE_ISR(void);
    #endif /* (SERIAL_DMA5_ACTIVE) */

    #if (SERIAL_DMA6_ACTIVE)
        void SERIAL_EP6_DMA_DONE_ISR(void);
    #endif /* (SERIAL_DMA6_ACTIVE) */

    #if (SERIAL_DMA7_ACTIVE)
        void SERIAL_EP7_DMA_DONE_ISR(void);
    #endif /* (SERIAL_DMA7_ACTIVE) */

    #if (SERIAL_DMA8_ACTIVE)
        void SERIAL_EP8_DMA_DONE_ISR(void);
    #endif /* (SERIAL_DMA8_ACTIVE) */

#else
    #if (SERIAL_EP_DMA_AUTO_OPT == 0u)
        CY_ISR_PROTO(SERIAL_EP_DMA_DONE_ISR);
    #endif /* (SERIAL_EP_DMA_AUTO_OPT == 0u) */
#endif /* (CY_PSOC4) */
#endif /* (SERIAL_EP_MANAGEMENT_DMA_AUTO) */


/***************************************
*         Request Handlers
***************************************/

uint8 SERIAL_HandleStandardRqst(void) ;
uint8 SERIAL_DispatchClassRqst(void)  ;
uint8 SERIAL_HandleVendorRqst(void)   ;


/***************************************
*    HID Internal references
***************************************/

#if defined(SERIAL_ENABLE_HID_CLASS)
    void SERIAL_FindReport(void)            ;
    void SERIAL_FindReportDescriptor(void)  ;
    void SERIAL_FindHidClassDecriptor(void) ;
#endif /* SERIAL_ENABLE_HID_CLASS */


/***************************************
*    MIDI Internal references
***************************************/

#if defined(SERIAL_ENABLE_MIDI_STREAMING)
    void SERIAL_MIDI_IN_EP_Service(void)  ;
#endif /* (SERIAL_ENABLE_MIDI_STREAMING) */


/***************************************
*    CDC Internal references
***************************************/

#if defined(SERIAL_ENABLE_CDC_CLASS)

    typedef struct
    {
        uint8  bRequestType;
        uint8  bNotification;
        uint8  wValue;
        uint8  wValueMSB;
        uint8  wIndex;
        uint8  wIndexMSB;
        uint8  wLength;
        uint8  wLengthMSB;
        uint8  wSerialState;
        uint8  wSerialStateMSB;
    } t_SERIAL_cdc_notification;

    uint8 SERIAL_GetInterfaceComPort(uint8 interface) ;
    uint8 SERIAL_Cdc_EpInit( const T_SERIAL_EP_SETTINGS_BLOCK CYCODE *pEP, uint8 epNum, uint8 cdcComNums) ;

    extern volatile uint8  SERIAL_cdc_dataInEpList[SERIAL_MAX_MULTI_COM_NUM];
    extern volatile uint8  SERIAL_cdc_dataOutEpList[SERIAL_MAX_MULTI_COM_NUM];
    extern volatile uint8  SERIAL_cdc_commInEpList[SERIAL_MAX_MULTI_COM_NUM];
#endif /* (SERIAL_ENABLE_CDC_CLASS) */


#endif /* CY_USBFS_SERIAL_pvt_H */


/* [] END OF FILE */
