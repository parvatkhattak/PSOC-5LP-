#include "project.h"
#include <stdio.h>

#define MPU6050_ADDRESS 0x68
#define MPU6050_PWR_MGMT_1 0x6B
#define MPU6050_ACCEL_XOUT_H 0x3B
#define MPU6050_TEMP_OUT_H 0x41
#define MPU6050_GYRO_XOUT_H 0x43

void InitializeSystem(void);
void MPU6050_Init(void);
void MPU6050_ReadAll(int16_t* ax, int16_t* ay, int16_t* az, int16_t* temp, int16_t* gx, int16_t* gy, int16_t* gz);

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    InitializeSystem();
    MPU6050_Init();
   
    for(;;)
    {
        int16_t ax, ay, az, temp, gx, gy, gz;
        // read i2c status and wait till it's free
        MPU6050_ReadAll(&ax, &ay, &az, &temp, &gx, &gy, &gz);
        
        char output[200];
        sprintf(output, "Accel X: %d, Y: %d, Z: %d, Temp: %d, Gyro X: %d, Y: %d, Z: %d\r\n", 
                ax, ay, az, temp, gx, gy, gz);
        // read status and wait till it's free 
        USBUART_PutString(output);
        
        CyDelay(100);  // Delay for readability in PuTTY
    }
}

void InitializeSystem(void)
{
    USBUART_Start(0, USBUART_5V_OPERATION);
    while (!USBUART_GetConfiguration()) {}
    
    I2C_Start();
    CyDelay(100);  // Allow time for initialization
}

void MPU6050_Init(void)
{
    I2C_MasterSendStart(MPU6050_ADDRESS, I2C_WRITE_XFER_MODE);
    I2C_MasterWriteByte(MPU6050_PWR_MGMT_1);
    I2C_MasterWriteByte(0x00);  // Wake up the MPU6050
    I2C_MasterSendStop();
    CyDelay(100);
}

void MPU6050_ReadAll(int16_t* ax, int16_t* ay, int16_t* az, int16_t* temp, int16_t* gx, int16_t* gy, int16_t* gz)
{
    uint8 data[14];
    
    I2C_MasterSendStart(MPU6050_ADDRESS, I2C_WRITE_XFER_MODE);
    I2C_MasterWriteByte(MPU6050_ACCEL_XOUT_H);
    I2C_MasterSendRestart(MPU6050_ADDRESS, I2C_READ_XFER_MODE);
    for (int i = 0; i < 14; i++)
    {
        data[i] = I2C_MasterReadByte(i == 13 ? I2C_NAK_DATA : I2C_ACK_DATA);
    }
    I2C_MasterSendStop();
    
    *ax = (data[0] << 8) | data[1];
    *ay = (data[2] << 8) | data[3];
    *az = (data[4] << 8) | data[5];
    *temp = (data[6] << 8) | data[7];
    *gx = (data[8] << 8) | data[9];
    *gy = (data[10] << 8) | data[11];
    *gz = (data[12] << 8) | data[13];
}
