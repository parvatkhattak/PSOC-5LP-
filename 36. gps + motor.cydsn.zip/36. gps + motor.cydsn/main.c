#include "project.h"
#include <stdio.h>

#define BUFFER_SIZE 9
#define GPS_BUFFER_SIZE 128

uint8 buffer[BUFFER_SIZE];
volatile uint8_t timer_flag = 0;  // Flag set by ISR

#define BUFFER_SIZE_1 64
uint8_t buffer_1[BUFFER_SIZE_1];
uint8_t count_1=0;
uint8_t data_index = 0;
uint8_t data_buffer[9];
uint16_t distance = 0; // Default distance value

#define pwm_max 3999
#define pwm_min 0
#define dir_up 0
#define dir_down 1

volatile uint16_t Interrupt=0;
volatile uint8_t dir=0;
#define MPU6050_ADDRESS 0x68
#define MPU6050_PWR_MGMT_1 0x6B
#define MPU6050_ACCEL_XOUT_H 0x3B
#define MPU6050_TEMP_OUT_H 0x41
#define MPU6050_GYRO_XOUT_H 0x43

#define GPS_UART_NUMBER 1

char gps_buffer[GPS_BUFFER_SIZE];
uint8_t gps_index = 0;

void send_byte_as_hex(uint8 byte) {
    char hex_str[5];
    sprintf(hex_str, "0x%02X ", byte);
    USBUART_PutString(hex_str);
}

CY_ISR(Timer_ISR) {
    Timer_STATUS;
    timer_flag = 1;
    if (dir == dir_up) {
        Interrupt += 150;
        if (Interrupt >= pwm_max) {
            dir = dir_down;
        }
    } else {
        Interrupt -= 150;
        if (Interrupt <= pwm_min) {
            dir = dir_up;
        }
    }
    PWM_WriteCompare(Interrupt);
}

CY_ISR(UART_isr) {
    /* Check for data received from LiDAR via UART */
    if (UART_GetRxBufferSize() > 0) {
        uint8_t data = UART_GetChar();
                
        /* Check for start of packet */
        if (data_index == 0 && data != 0x59) {
            return; // Wait for start byte
        }
                
        data_buffer[data_index++] = data;
                
        if (data_index >= 9) {
            /* Validate packet */
            if (data_buffer[0] == 0x59 && data_buffer[1] == 0x59) {
                /* Calculate checksum */
                uint8_t checksum = 0;
                for (int i = 0; i < 8; i++) {
                    checksum += data_buffer[i];
                }
                if (checksum == data_buffer[8]) {
                    /* Valid packet, extract distance */
                    distance = (data_buffer[3] << 8) | data_buffer[2];
                    
                    if (distance < 15) {
                        buzzer_Write(1);
                    } else {
                        buzzer_Write(0);
                    }
                }
            }
            data_index = 0;
        }
    }
}

CY_ISR(GPS_isr) {
    while (UART_1_GetRxBufferSize() > 0) {
        char data = UART_1_GetChar();
        if (data == '\n') {
            gps_buffer[gps_index] = '\0';
            // Process GPS data here
            gps_index = 0;
        } else {
            gps_buffer[gps_index++] = data;
            if (gps_index >= GPS_BUFFER_SIZE) {
                gps_index = 0; // Prevent buffer overflow
            }
        }
    }
}

void process_gps_data(const char* nmea_sentence) {
    // Example of simple NMEA parsing for $GPGGA sentence
    if (strncmp(nmea_sentence, "$GPGGA", 6) == 0) {
        char time[11], latitude[11], longitude[12], fix[2], satellites[3], hdop[5], altitude[8];
        
        sscanf(nmea_sentence, "$GPGGA,%10[^,],%10[^,],%*c,%11[^,],%*c,%1[^,],%2[^,],%4[^,],%7[^,]",
               time, latitude, longitude, fix, satellites, hdop, altitude);
        
        char output[200];
        sprintf(output,
                "GPS Data:\r\n"
                "Time: %s\r\n"
                "Latitude: %s\r\n"
                "Longitude: %s\r\n"
                "Fix: %s\r\n"
                "Satellites: %s\r\n"
                "HDOP: %s\r\n"
                "Altitude: %s\r\n\n",
                time, latitude, longitude, fix, satellites, hdop, altitude);
        
        USBUART_PutString(output);
    }
}

int main(void) {
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_Start();
    USBUART_Start(0, USBUART_5V_OPERATION);
    Timer_Start();
    UART_1_Start();
    
    isr_1_StartEx(Timer_ISR); // Start the Timer ISR
    isr_2_StartEx(UART_isr);
    isr_3_StartEx(GPS_isr);
    
    while (!USBUART_GetConfiguration()) {}
    
    USBUART_CDC_Init();
    ADC_SAR_Start();
    ADC_SAR_StartConvert();
    PWM_Start();
    I2C_Start();
    
    // Initialize MPU6050
    I2C_MasterSendStart(MPU6050_ADDRESS, I2C_WRITE_XFER_MODE);
    I2C_MasterWriteByte(MPU6050_PWR_MGMT_1);
    I2C_MasterWriteByte(0x00);  // Wake up the MPU6050
    I2C_MasterSendStop();
    
    /* Main loop */
    for (;;) {
        /* Check for timer interrupt flag */
        if (timer_flag) {
            uint16 potentiometer = ADC_SAR_GetResult16();
        
            int16_t ax, ay, az, temp, gx, gy, gz;
            uint8 data[14];
    
            I2C_MasterSendStart(MPU6050_ADDRESS, I2C_WRITE_XFER_MODE);
            I2C_MasterWriteByte(MPU6050_ACCEL_XOUT_H);
            I2C_MasterSendRestart(MPU6050_ADDRESS, I2C_READ_XFER_MODE);
            for (int i = 0; i < 14; i++) {
                data[i] = I2C_MasterReadByte(i == 13 ? I2C_NAK_DATA : I2C_ACK_DATA);
            }
            I2C_MasterSendStop();
    
            ax = (data[0] << 8) | data[1];
            ay = (data[2] << 8) | data[3];
            az = (data[4] << 8) | data[5];
            temp = (data[6] << 8) | data[7];
            gx = (data[8] << 8) | data[9];
            gy = (data[10] << 8) | data[11];
            gz = (data[12] << 8) | data[13];
        
            char output[500];
            sprintf(output, 
                    "Potentiometer reading: %d\r\n"
                    "Distance: %ucm\r\n"
                    "Accel X: %d, Y: %d, Z: %d\r\n"
                    "Temp: %d\r\n"
                    "Gyro X: %d, Y: %d, Z: %d\r\n\n", 
                    potentiometer, distance, ax, ay, az, temp, gx, gy, gz);
            
            // Send the output string via USBUART
            USBUART_PutString(output);
        
            timer_flag = 0;
        }
        
        /* Check for USBUART activity */
        if (USBUART_DataIsReady() != 0) {
            uint16 count = USBUART_GetAll(buffer);
            if (count != 0u) {
                /* Echo back to USBUART terminal */
                USBUART_PutData(buffer, count);
            }
        }
        
        /* Process GPS data */
        if (gps_buffer[0] != '\0') {
            process_gps_data(gps_buffer);
            gps_buffer[0] = '\0';  // Clear the buffer after processing
        }
    }
}
