/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

#define BUFFER_SIZE 64
uint8_t buffer[BUFFER_SIZE];


int main(void)
{
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start(); /* Start UART component */
    USBUART_Start(0, USBUART_5V_OPERATION); /* Start USBFS component */
    
    while (!USBUART_GetConfiguration())
    {
        /* Wait for device to enumerate */
    }
    
    USBUART_CDC_Init(); /* Initialize CDC class */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        /* Place your application code here. */
        if (UART_GetRxBufferSize() > 0)
        {
            uint8_t count = UART_GetRxBufferSize();
            if (count > BUFFER_SIZE)
                count = BUFFER_SIZE;
            
            for (uint8_t i = 0; i < count; i++)
            {
                buffer[i] = UART_GetChar();
            }
            
            /* Send received data via USBUART */
            while (USBUART_CDCIsReady() == 0);
            USBUART_PutData(buffer, count);
        }
    }
}

/* [] END OF FILE */
