#include "project.h"
#include <stdio.h>

#define BUFFER_SIZE 9

uint8 buffer[BUFFER_SIZE];
#define pwm_max 3999
#define pwm_min 0
#define dir_up 0
#define dir_down 1

volatile uint16_t Interrupt = 0;
volatile uint8_t dir = 0;
#define MPU6050_ADDRESS 0x68
#define MPU6050_PWR_MGMT_1 0x6B
#define MPU6050_ACCEL_XOUT_H 0x3B
#define MPU6050_TEMP_OUT_H 0x41
#define MPU6050_GYRO_XOUT_H 0x43
uint16_t distance = 0; // Default distance value
uint8_t data_index = 0;
uint8_t data_buffer[9] = {0};
void send_byte_as_hex(uint8 byte) {
    char hex_str[5];
    sprintf(hex_str, "0x%02X ", byte);
    USBUART_PutString(hex_str);
}

volatile uint8_t timer_flag = 0;  // Flag set by ISR

CY_ISR(Timer_Int)
{
    Timer_STATUS;
    timer_flag = 1;
    if (dir == dir_up) {
        Interrupt += 150;
        if (Interrupt >= pwm_max) {
            dir = dir_down;
        }
    } else {
        Interrupt -= 150;
        if (Interrupt <= pwm_min) {
            dir = dir_up;
        }
    }
    PWM_WriteCompare(Interrupt);
}
CY_ISR(Rx_Int){
     
            
            
            
            // Read LiDAR data
            while (UART_GetRxBufferSize() > 0) {
                uint8_t data_byte = UART_GetChar();
                
                if (data_index == 0 && data_byte != 0x59) {
                    continue; // Wait for start byte
                }
                
                data_buffer[data_index++] = data_byte;
                
                if (data_index >= 9) {
                    if (data_buffer[0] == 0x59 && data_buffer[1] == 0x59) {
                        uint8_t checksum = 0;
                        for (int i = 0; i < 8; i++) {
                            checksum += data_buffer[i];
                        }
                        
                        if (checksum == data_buffer[8]) {
                            distance = (data_buffer[3] << 8) | data_buffer[2];
                            
                            if (distance < 15) {
                                buzzer_Write(1);
                            } else {
                                buzzer_Write(0);
                            }
                        }
                    }
                    data_index = 0;
                }
            }
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_Start();
    USBUART_Start(0, USBUART_5V_OPERATION);
    
    while (!USBUART_GetConfiguration()) {}
    
    USBUART_CDC_Init();
    
   
    ADC_SAR_Start();
    ADC_SAR_StartConvert();
    isr_1_ClearPending();
    isr_1_StartEx(Timer_Int);
    isr_2_ClearPending();
    isr_2_StartEx(Rx_Int);
    PWM_Start();
    Timer_Start();
    I2C_Start();
    
    // MPU6050 initialization
    I2C_MasterSendStart(MPU6050_ADDRESS, I2C_WRITE_XFER_MODE);
    I2C_MasterWriteByte(MPU6050_PWR_MGMT_1);
    I2C_MasterWriteByte(0x00);  // Wake up the MPU6050
    I2C_MasterSendStop();
    
    /* Main loop */
    for (;;) {
        if (timer_flag) {
           
            
            // Read MPU6050 data
            I2C_MasterSendStart(MPU6050_ADDRESS, I2C_WRITE_XFER_MODE);
            I2C_MasterWriteByte(MPU6050_ACCEL_XOUT_H);
            I2C_MasterSendRestart(MPU6050_ADDRESS, I2C_READ_XFER_MODE);
            uint8 data[14];
            uint16_t potentiometer_value = ADC_SAR_GetResult16();
            for (int i = 0; i < 14; i++) {
                data[i] = I2C_MasterReadByte(i == 13 ? I2C_NAK_DATA : I2C_ACK_DATA);
            }
            I2C_MasterSendStop();
            int16_t ax, ay, az, temp, gx, gy, gz;
           
            ax = (data[0] << 8) | data[1];
            ay = (data[2] << 8) | data[3];
            az = (data[4] << 8) | data[5];
            temp = (data[6] << 8) | data[7];
            gx = (data[8] << 8) | data[9];
            gy = (data[10] << 8) | data[11];
            gz = (data[12] << 8) | data[13];
            
            // Create a single formatted string
            char output[500];
            sprintf(output, 
                    "Potentiometer reading: %d\r\n"
                    "Distance: %ucm\r\n"
                    "Accel X: %d, Y: %d, Z: %d\r\n"
                    "Temp: %d\r\n"
                    "Gyro X: %d, Y: %d, Z: %d\r\n\n", 
                    potentiometer_value, distance, ax, ay, az, temp, gx, gy, gz);
            
            // Send the output string via USBUART
            USBUART_PutString(output);
            
            timer_flag = 0;
        }
        
        // Check for USBUART activity
        if (USBUART_DataIsReady() != 0) {
            uint16 count = USBUART_GetAll(buffer);
            if (count != 0u) {
                // Echo back to USBUART terminal
                USBUART_PutData(buffer, count);
            }
        }
    }
}
