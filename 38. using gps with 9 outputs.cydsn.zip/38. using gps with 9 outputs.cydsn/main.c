#include "project.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 128

// Global variables to store parsed GPS data
float latitude = 0.0;
float longitude = 0.0;
float altitude = 0.0;
float speed_over_ground = 0.0;
float course_over_ground = 0.0;
char utc_time[7] = {0}; // hhmmss format
char status = '\0';     // 'A' or 'V'
int satellites_used = 0;
float hdop = 0.0;
float vdop = 0.0;

// Function to parse $GPGGA sentence
void parse_GPGGA(const char *sentence) {
    char *token;
    int count = 0;
    token = strtok((char *)sentence, ",");
    while (token != NULL) {
        switch (count) {
            case 1: // UTC Position
                snprintf(utc_time, sizeof(utc_time), "%s", token);
                break;
            case 2: // Latitude
                latitude = atof(token);
                break;
            case 3: // N/S Indicator (not used directly)
                break;
            case 4: // Longitude
                longitude = atof(token);
                break;
            case 5: // E/W Indicator (not used directly)
                break;
            case 9: // MSL Altitude
                altitude = atof(token);
                break;
            case 6: // Position Fix Indicator
                // You can store or process this value as needed
                break;
            case 7: // Satellites Used
                satellites_used = atoi(token);
                break;
            case 8: // HDOP (Horizontal Dilution of Precision)
                hdop = atof(token);
                break;
            case 11: // VDOP (Vertical Dilution of Precision)
                vdop = atof(token);
                break;
            default:
                break;
        }
        token = strtok(NULL, ",");
        count++;
    }
}

// Function to parse $GPRMC sentence
void parse_GPRMC(const char *sentence) {
    char *token;
    int count = 0;
    token = strtok((char *)sentence, ",");
    while (token != NULL) {
        switch (count) {
            case 1: // UTC Position
                snprintf(utc_time, sizeof(utc_time), "%s", token);
                break;
            case 2: // Status
                status = token[0];
                break;
            case 3: // Latitude
                latitude = atof(token);
                break;
            case 4: // N/S Indicator (not used directly)
                break;
            case 5: // Longitude
                longitude = atof(token);
                break;
            case 6: // E/W Indicator (not used directly)
                break;
            case 7: // Speed Over Ground (knots)
                speed_over_ground = atof(token);
                break;
            case 8: // Course Over Ground (degrees)
                course_over_ground = atof(token);
                break;
            case 9: // Date (not used directly)
                break;
            default:
                break;
        }
        token = strtok(NULL, ",");
        count++;
    }
}

// Function to parse $GPVTG sentence
void parse_GPVTG(const char *sentence) {
    char *token;
    int count = 0;
    token = strtok((char *)sentence, ",");
    while (token != NULL) {
        switch (count) {
            case 1: // Course Over Ground (degrees)
                course_over_ground = atof(token);
                break;
            case 5: // Speed Over Ground (knots)
                speed_over_ground = atof(token);
                break;
            default:
                break;
        }
        token = strtok(NULL, ",");
        count++;
    }
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start(); /* Start UART component */
    USBUART_Start(0, USBUART_5V_OPERATION); /* Start USBFS component */
    
    while (!USBUART_GetConfiguration())
    {
        /* Wait for device to enumerate */
    }
    
    USBUART_CDC_Init(); /* Initialize CDC class */

    char nmea_sentence[BUFFER_SIZE];
    uint8_t buffer[BUFFER_SIZE];

    for(;;)
    {
        /* Check if there is data in UART buffer */
        if (UART_GetRxBufferSize() > 0)
        {
            uint8_t count = UART_GetRxBufferSize();
            if (count > BUFFER_SIZE)
                count = BUFFER_SIZE;
            
            /* Read data from UART buffer */
            for (uint8_t i = 0; i < count; i++)
            {
                buffer[i] = UART_GetChar();
            }

            /* Copy buffer to NMEA sentence and null-terminate it */
            memcpy(nmea_sentence, buffer, count);
            nmea_sentence[count] = '\0';
            
            /* Parse NMEA sentence */
            if (strncmp(nmea_sentence, "$GPGGA", 6) == 0)
            {
                parse_GPGGA(nmea_sentence);
            }
            else if (strncmp(nmea_sentence, "$GPRMC", 6) == 0)
            {
                parse_GPRMC(nmea_sentence);
            }
            else if (strncmp(nmea_sentence, "$GPVTG", 6) == 0)
            {
                parse_GPVTG(nmea_sentence);
            }

            /* Example: Format and send data via USBUART */
            char output_buffer[BUFFER_SIZE];
            snprintf(output_buffer, BUFFER_SIZE, "Latitude: %.5f° %c\r\nLongitude: %.5f° %c\r\nAltitude: %.1f meters\r\n\nSpeed Over Ground: %.2f km/h\r\nCourse Over Ground: %.2f degrees\r\nTime: %c%c:%c%c UTC\r\nStatus: %c (valid)\r\nNumber of Satellites: %d\r\nDOP Values: HDOP = %.1f, VDOP = %.1f\r\n\n",
                     fabs(latitude), latitude >= 0 ? 'N' : 'S',
                     fabs(longitude), longitude >= 0 ? 'E' : 'W',
                     altitude, speed_over_ground, course_over_ground,
                     utc_time[0], utc_time[1], utc_time[2], utc_time[3],
                     status, satellites_used, hdop, vdop);
            
            /* Send formatted data via USBUART */
            while (USBUART_CDCIsReady() == 0);
            USBUART_PutString(output_buffer);
        }
    }
}
