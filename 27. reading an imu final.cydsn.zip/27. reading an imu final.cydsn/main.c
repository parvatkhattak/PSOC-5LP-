/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include<stdio.h>
# define pwm_max 3999
# define pwm_min 0
# define dir_up 0
# define dir_down 1

volatile uint16_t Interrupt=0;
volatile uint8_t dir=0;
#define MPU6050_ADDRESS 0x68
#define MPU6050_PWR_MGMT_1 0x6B
#define MPU6050_ACCEL_XOUT_H 0x3B
#define MPU6050_TEMP_OUT_H 0x41
#define MPU6050_GYRO_XOUT_H 0x43

volatile uint8_t timer_flag = 0;  // Flag set by ISR

CY_ISR(Timer_Int)
{
    Timer_STATUS;
    timer_flag = 1;  // Set flag to indicate timer interrupt occurred
   
    if (dir==dir_up){
        Interrupt+=150;
        if (Interrupt>=pwm_max){
            dir=dir_down;
        }
    }
    else {
        Interrupt-=150;
        if (Interrupt<=pwm_min){
            dir=dir_up;
        }
    }
    PWM_WriteCompare(Interrupt);
    uint16 interrupt;
    interrupt=ADC_SAR_GetResult16();
    char send[100];
    sprintf(send,"potentiometer reading:%d\r\n",interrupt);
    USBUART_PutString(send);
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    USBUART_Start(0,USBUART_5V_OPERATION);
    while(USBUART_GetConfiguration()==0){}
    
    ADC_SAR_Start();
    ADC_SAR_StartConvert();
    isr_1_ClearPending();
    isr_1_StartEx(Timer_Int);
    PWM_Start();
    Timer_Start();
    I2C_Start();
    
    //MPU6050_Init();
    I2C_MasterSendStart(MPU6050_ADDRESS, I2C_WRITE_XFER_MODE);
    I2C_MasterWriteByte(MPU6050_PWR_MGMT_1);
    I2C_MasterWriteByte(0x00);  // Wake up the MPU6050
    I2C_MasterSendStop();
    
   
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
   
    for(;;)
    {
        /* Place your application code here. */
        if (timer_flag) {
        int16_t ax, ay, az, temp, gx, gy, gz;
        int16_t *aax=&ax, *aay=&ay, *aaz=&az, *atemp=&temp, *agx=&gx, *agy=&gy, *agz=&gz;
        // read i2c status and wait till it's free
        //MPU6050_ReadAll(&ax, &ay, &az, &temp, &gx, &gy, &gz);
        uint8 data[14];
    
    I2C_MasterSendStart(MPU6050_ADDRESS, I2C_WRITE_XFER_MODE);
    I2C_MasterWriteByte(MPU6050_ACCEL_XOUT_H);
    I2C_MasterSendRestart(MPU6050_ADDRESS, I2C_READ_XFER_MODE);
    for (int i = 0; i < 14; i++)
    {
        data[i] = I2C_MasterReadByte(i == 13 ? I2C_NAK_DATA : I2C_ACK_DATA);
    }
    I2C_MasterSendStop();
    
    *aax = (data[0] << 8) | data[1];
    *aay = (data[2] << 8) | data[3];
    *aaz = (data[4] << 8) | data[5];
    *atemp = (data[6] << 8) | data[7];
    *agx = (data[8] << 8) | data[9];
    *agy = (data[10] << 8) | data[11];
    *agz = (data[12] << 8) | data[13];
        
        char output[200];
        sprintf(output, "Accel X: %d, Y: %d, Z: %d\r\nTemp: %d\r\nGyro X: %d, Y: %d, Z: %d\r\n\n", 
                ax, ay, az, temp, gx, gy, gz);
        // read status and wait till it's free 
        USBUART_PutString(output);;
        timer_flag = 0 ;
        }
        
        
    }
    
   
}
