/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include<stdio.h>
CY_ISR(Timer_1_Int)
{
    uint16 interrupt_1;
    interrupt_1=ADC_SAR_GetResult16();
    char send[100];
    sprintf(send,"%d\r\n",interrupt_1);
    USBUART_PutString(send);
    
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    USBUART_Start(0,USBUART_5V_OPERATION);
    while(USBUART_GetConfiguration()==0){}
    
    ADC_SAR_Start();
    ADC_SAR_StartConvert();
    isr_2_ClearPending();
    isr_2_StartEx(Timer_1_Int);
    Timer_1_Start();
    
   
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
   
    for(;;)
    {
        /* Place your application code here. */
        
       
    }
}

/* [] END OF FILE */
