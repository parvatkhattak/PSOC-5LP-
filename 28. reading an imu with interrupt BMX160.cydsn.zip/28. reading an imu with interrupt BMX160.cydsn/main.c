#include "project.h"
#include <stdio.h>

// BMX160 I2C address (assuming SDO is low)
#define BMX160_ADDRESS 0x69

// BMX160 Register addresses
#define BMX160_CMD_REG 0x7E
#define BMX160_ACC_RANGE_REG 0x41
#define BMX160_GYR_RANGE_REG 0x43
#define BMX160_MAG_CONF_REG 0x44
#define BMX160_DATA_START 0x04

// BMX160 power modes
#define BMX160_ACC_NORMAL_MODE 0x11
#define BMX160_GYR_NORMAL_MODE 0x15
#define BMX160_MAG_NORMAL_MODE 0x19

volatile uint8_t timer_flag = 0;  // Flag set by ISR

CY_ISR(Timer_ISR)
{
    timer_flag = 1;  // Set flag to indicate timer interrupt occurred
}

void BMX160_Init()
{
    // Wake up the accelerometer, gyroscope, and magnetometer
    if (I2C_MasterSendStart(BMX160_ADDRESS, I2C_WRITE_XFER_MODE) != I2C_MSTR_NO_ERROR)
    {
        printf("I2C Start Error\n");
        return;
    }
    I2C_MasterWriteByte(BMX160_CMD_REG);
    I2C_MasterWriteByte(BMX160_ACC_NORMAL_MODE);
    I2C_MasterSendStop();
    CyDelay(50); // Wait for 50ms
    
    if (I2C_MasterSendStart(BMX160_ADDRESS, I2C_WRITE_XFER_MODE) != I2C_MSTR_NO_ERROR)
    {
        printf("I2C Start Error\n");
        return;
    }
    I2C_MasterWriteByte(BMX160_CMD_REG);
    I2C_MasterWriteByte(BMX160_GYR_NORMAL_MODE);
    I2C_MasterSendStop();
    CyDelay(50); // Wait for 50ms

    if (I2C_MasterSendStart(BMX160_ADDRESS, I2C_WRITE_XFER_MODE) != I2C_MSTR_NO_ERROR)
    {
        printf("I2C Start Error\n");
        return;
    }
    I2C_MasterWriteByte(BMX160_CMD_REG);
    I2C_MasterWriteByte(BMX160_MAG_NORMAL_MODE);
    I2C_MasterSendStop();
    CyDelay(50); // Wait for 50ms

    // Configure accelerometer range
    if (I2C_MasterSendStart(BMX160_ADDRESS, I2C_WRITE_XFER_MODE) != I2C_MSTR_NO_ERROR)
    {
        printf("I2C Start Error\n");
        return;
    }
    I2C_MasterWriteByte(BMX160_ACC_RANGE_REG);
    I2C_MasterWriteByte(0x03); // Set accelerometer range to +/- 2g
    I2C_MasterSendStop();

    // Configure gyroscope range
    if (I2C_MasterSendStart(BMX160_ADDRESS, I2C_WRITE_XFER_MODE) != I2C_MSTR_NO_ERROR)
    {
        printf("I2C Start Error\n");
        return;
    }
    I2C_MasterWriteByte(BMX160_GYR_RANGE_REG);
    I2C_MasterWriteByte(0x00); // Set gyroscope range to 2000 dps
    I2C_MasterSendStop();

    // Configure magnetometer settings (if needed, adjust according to your requirements)
    if (I2C_MasterSendStart(BMX160_ADDRESS, I2C_WRITE_XFER_MODE) != I2C_MSTR_NO_ERROR)
    {
        printf("I2C Start Error\n");
        return;
    }
    I2C_MasterWriteByte(BMX160_MAG_CONF_REG);
    I2C_MasterWriteByte(0x00); // Default magnetometer settings
    I2C_MasterSendStop();
}

void InitializeUSB()
{
    USBFS_Start(0, USBFS_5V_OPERATION);
    while (!USBFS_GetConfiguration())
    {
        // Wait for Device to enumerate
    }
    USBFS_CDC_Init();
    printf("USB Initialized\n");
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Initialize USB */
    InitializeUSB();

    I2C_Start();
    BMX160_Init();

    timer_Start();
    isr_1_StartEx(Timer_ISR);

    for (;;)
    {
        if (timer_flag)
        {
            int16_t ax, ay, az, gx, gy, gz, mx, my, mz;
            int16_t *aax = &ax, *aay = &ay, *aaz = &az;
            int16_t *agx = &gx, *agy = &gy, *agz = &gz;
            int16_t *amx = &mx, *amy = &my, *amz = &mz;

            uint8 data[20]; // 6 bytes for accelerometer, 6 for gyroscope, 8 for magnetometer

            if (I2C_MasterSendStart(BMX160_ADDRESS, I2C_WRITE_XFER_MODE) != I2C_MSTR_NO_ERROR)
            {
                printf("I2C Start Error\n");
                continue;
            }
            I2C_MasterWriteByte(BMX160_DATA_START);
            if (I2C_MasterSendRestart(BMX160_ADDRESS, I2C_READ_XFER_MODE) != I2C_MSTR_NO_ERROR)
            {
                printf("I2C Restart Error\n");
                continue;
            }
            for (int i = 0; i < 20; i++)
            {
                data[i] = I2C_MasterReadByte(i == 19 ? I2C_NAK_DATA : I2C_ACK_DATA);
            }
            I2C_MasterSendStop();

            *aax = (data[1] << 8) | data[0];
            *aay = (data[3] << 8) | data[2];
            *aaz = (data[5] << 8) | data[4];
            *agx = (data[7] << 8) | data[6];
            *agy = (data[9] << 8) | data[8];
            *agz = (data[11] << 8) | data[10];
            *amx = (data[13] << 8) | data[12];
            *amy = (data[15] << 8) | data[14];
            *amz = (data[17] << 8) | data[16];

            char output[200];
            sprintf(output, "Accel X: %d, Y: %d, Z: %d\r\nGyro X: %d, Y: %d, Z: %d\r\nMag X: %d, Y: %d, Z: %d\r\n\n", 
                    ax, ay, az, gx, gy, gz, mx, my, mz);

            // Ensure USBFS is ready before sending data
            if (USBFS_CDCIsReady())
            {
                USBFS_PutString(output);
            }
            else
            {
                printf("USBFS Not Ready\n");
            }

            timer_flag = 0;
        }
    }
}
