#include "project.h"
#include <stdio.h>

#define BUFFER_SIZE 9

uint8 buffer[BUFFER_SIZE];
volatile uint8_t timer_flag = 0;  // Flag set by ISR




void send_byte_as_hex(uint8 byte) {
    char hex_str[5];
    sprintf(hex_str, "0x%02X ", byte);
    USBUART_PutString(hex_str);
}

CY_ISR(Timer_ISR) {
    Timer_STATUS;
    timer_flag = 1;   
}

int main(void) {
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_Start();
    USBUART_Start(0, USBUART_5V_OPERATION);
    Timer_Start();
    
    isr_1_StartEx(Timer_ISR); // Start the Timer ISR
    
    while (!USBUART_GetConfiguration()){}
    
    USBUART_CDC_Init();
    
    uint8_t data_index = 0;
    uint8_t data_buffer[9];
    
    /* Main loop */
    for(;;) 
    {
        /* Check for timer interrupt flag */
        if (timer_flag) {
            
            /* Check for data received from LiDAR via UART */
            if (UART_GetRxBufferSize() > 0) {
                uint8_t data = UART_GetChar();
                
                /* Check for start of packet */
                if (data_index == 0 && data != 0x59) {
                    continue; // Wait for start byte
                }
                
                data_buffer[data_index++] = data;
                
                if (data_index >= 9) {
                    /* Validate packet */
                    if (data_buffer[0] == 0x59 && data_buffer[1] == 0x59) {
                        /* Calculate checksum */
                        uint8_t checksum = 0;
                        for (int i = 0; i < 8; i++) {
                            checksum += data_buffer[i];
                        }
                        
                        if (checksum == data_buffer[8]) {
                            /* Valid packet, extract distance */
                            uint16_t distance = (data_buffer[3] << 8) | data_buffer[2];
                            
                            /* Convert distance to string */
                            char distance_str[20];
                            sprintf(distance_str, "Distance:%ucm\r\n", distance);
                            
                            /* Send distance over USBUART */
                            USBUART_PutString(distance_str);
                            
                            if (distance < 15) {
                                buzzer_Write(1);
                            } else if (distance > 15) {
                                buzzer_Write(0);
                            }
                        }
                    }
                    data_index = 0;;
                    timer_flag = 0 ;
        }
                }
            }
        }
        
        /* Check for USBUART activity */
        if (USBUART_DataIsReady() != 0) {
            uint16 count = USBUART_GetAll(buffer);
            if (count != 0u) {
                /* Echo back to USBUART terminal */
                USBUART_PutData(buffer, count);
            }
        }
    }

