#include "project.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 128

// Global variables to store parsed GPS data
float latitude = 0.0;
float longitude = 0.0;
float speed_over_ground = 0.0;
float course_over_ground = 0.0;
char utc_time[12] = {0}; // hhmmss.sss format
char date[7] = {0};      // ddmmyy format
char status = '\0';      // 'A' or 'V'

// Function to parse $GPGGA sentence
void parse_GPGGA(const char *sentence) {
    char *token;
    int count = 0;
    token = strtok((char *)sentence, ",");
    while (token != NULL) {
        switch (count) {
            case 1: // UTC Position
                strcpy(utc_time, token);
                break;
            case 2: // Latitude
                latitude = atof(token);
                break;
            case 3: // N/S Indicator (not used directly)
                break;
            case 4: // Longitude
                longitude = atof(token);
                break;
            case 7: // Satellites Used
                // You can store or process this value as needed
                break;
            case 9: // Altitude (MSL)
                // You can store or process this value as needed
                break;
            default:
                break;
        }
        token = strtok(NULL, ",");
        count++;
    }
}

// Function to parse $GPRMC sentence
void parse_GPRMC(const char *sentence) {
    char *token;
    int count = 0;
    token = strtok((char *)sentence, ",");
    while (token != NULL) {
        switch (count) {
            case 1: // UTC Position
                strcpy(utc_time, token);
                break;
            case 2: // Status
                status = token[0];
                break;
            case 3: // Latitude
                latitude = atof(token);
                break;
            case 4: // N/S Indicator (not used directly)
                break;
            case 5: // Longitude
                longitude = atof(token);
                break;
            case 6: // E/W Indicator (not used directly)
                break;
            case 7: // Speed Over Ground
                speed_over_ground = atof(token);
                break;
            case 8: // Course Over Ground
                course_over_ground = atof(token);
                break;
            case 9: // Date
                strcpy(date, token);
                break;
            default:
                break;
        }
        token = strtok(NULL, ",");
        count++;
    }
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start(); /* Start UART component */
    USBUART_Start(0, USBUART_5V_OPERATION); /* Start USBFS component */
    
    while (!USBUART_GetConfiguration())
    {
        /* Wait for device to enumerate */
    }
    
    USBUART_CDC_Init(); /* Initialize CDC class */

    char nmea_sentence[BUFFER_SIZE];
    uint8_t buffer[BUFFER_SIZE];

    for(;;)
    {
        /* Check if there is data in UART buffer */
        if (UART_GetRxBufferSize() > 0)
        {
            uint8_t count = UART_GetRxBufferSize();
            if (count > BUFFER_SIZE)
                count = BUFFER_SIZE;
            
            /* Read data from UART buffer */
            for (uint8_t i = 0; i < count; i++)
            {
                buffer[i] = UART_GetChar();
            }

            /* Copy buffer to NMEA sentence and null-terminate it */
            memcpy(nmea_sentence, buffer, count);
            nmea_sentence[count] = '\0';
            
            /* Parse NMEA sentence */
            if (strncmp(nmea_sentence, "$GPGGA", 6) == 0)
            {
                parse_GPGGA(nmea_sentence);
            }
            else if (strncmp(nmea_sentence, "$GPRMC", 6) == 0)
            {
                parse_GPRMC(nmea_sentence);
            }

            /* Example: Format and send data via USBUART */
            char output_buffer[BUFFER_SIZE];
            snprintf(output_buffer, BUFFER_SIZE, "Latitude: %.5f\r\nLongitude: %.5f\r\nSpeed: %.2f km/h\r\nCourse: %.2f degrees\n\r\n",
                     latitude, longitude, speed_over_ground, course_over_ground);
            
            /* Send formatted data via USBUART */
            while (USBUART_CDCIsReady() == 0);
            USBUART_PutString(output_buffer);
        }
    }
}

