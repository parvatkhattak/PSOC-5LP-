/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
# define pwm_max 1999
# define pwm_min 0
# define dir_up 0
# define dir_down 1
# define pwm_duration 2

volatile int16_t compare=0;
volatile uint8_t dir=0;
volatile int duration=0;

CY_ISR(isr)
{
    uint8_t status;
    status= PWM_ReadStatusRegister();
    duration++;
    if (duration>pwm_duration){
        return;
    }
    else if (duration<= pwm_duration) {
        duration=0;
    }
    
    if (status & PWM_STATUS_TC) {
        if (dir==dir_up){
        compare+=5;
            if (compare>=pwm_max) {
                compare=pwm_max;
                dir=dir_down;
            }
        }
            
        else if (dir==dir_down){
            compare-=5;
            if (compare<=pwm_min){
                compare=pwm_min;
                dir=dir_up;
            }
        }
        
    }
    PWM_WriteCompare(compare);
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    PWM_Start();
    isr_1_ClearPending();
    isr_1_StartEx(isr);

    for(;;)
    {
        /* Place your application code here. */
        
        
    }
}

/* [] END OF FILE */
